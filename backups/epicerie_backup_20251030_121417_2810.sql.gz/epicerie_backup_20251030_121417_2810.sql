--
-- PostgreSQL database dump
--

\restrict DZCW6HzODzkNglkXRprWnA2N4URLjpg4ol9X5wKZg1eYTS9jCyWgY0gsDUJ5XfI

-- Dumped from database version 16.10 (Debian 16.10-1.pgdg13+1)
-- Dumped by pg_dump version 17.6 (Debian 17.6-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: type_cat; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.type_cat AS ENUM (
    'Epicerie sucree',
    'Epicerie salee',
    'Alcool',
    'Autre',
    'Afrique',
    'Boissons',
    'Hygiene'
);


ALTER TYPE public.type_cat OWNER TO postgres;

--
-- Name: type_mouvement; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.type_mouvement AS ENUM (
    'ENTREE',
    'SORTIE',
    'TRANSFERT',
    'INVENTAIRE'
);


ALTER TYPE public.type_mouvement OWNER TO postgres;

--
-- Name: update_stock_actuel(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_stock_actuel() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Mettre à jour le stock dans la table produits
    UPDATE produits
    SET stock_actuel = stock_actuel + CASE
        WHEN NEW.type = 'ENTREE' THEN NEW.quantite
        WHEN NEW.type = 'SORTIE' THEN -NEW.quantite
        -- Ajoutez ici d'autres types si nécessaire (ex: INVENTAIRE, TRANSFERT)
        ELSE 0
    END
    WHERE id = NEW.produit_id;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_stock_actuel() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: mouvements_stock; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mouvements_stock (
    id integer NOT NULL,
    produit_id integer NOT NULL,
    type public.type_mouvement NOT NULL,
    quantite numeric(12,3) NOT NULL,
    source text,
    date_mvt timestamp without time zone DEFAULT now() NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT mouvements_stock_quantite_check CHECK ((quantite > (0)::numeric))
);


ALTER TABLE public.mouvements_stock OWNER TO postgres;

--
-- Name: mouvements_stock_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mouvements_stock_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mouvements_stock_id_seq OWNER TO postgres;

--
-- Name: mouvements_stock_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mouvements_stock_id_seq OWNED BY public.mouvements_stock.id;


--
-- Name: produits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.produits (
    id integer NOT NULL,
    nom text NOT NULL,
    categorie public.type_cat DEFAULT 'Autre'::public.type_cat,
    prix_achat numeric(10,2),
    prix_vente numeric(10,2),
    tva numeric(5,2) DEFAULT 0,
    seuil_alerte numeric(12,3) DEFAULT 0,
    actif boolean DEFAULT true,
    stock_actuel numeric(12,3) DEFAULT 0,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT produits_prix_achat_check CHECK ((prix_achat >= (0)::numeric)),
    CONSTRAINT produits_prix_vente_check CHECK ((prix_vente >= (0)::numeric)),
    CONSTRAINT produits_seuil_alerte_check CHECK ((seuil_alerte >= (0)::numeric)),
    CONSTRAINT produits_stock_actuel_check CHECK ((stock_actuel >= (0)::numeric)),
    CONSTRAINT produits_tva_check CHECK ((tva >= (0)::numeric))
);


ALTER TABLE public.produits OWNER TO postgres;

--
-- Name: produits_barcodes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.produits_barcodes (
    id integer NOT NULL,
    produit_id integer NOT NULL,
    code text NOT NULL,
    symbologie text,
    pays_iso2 character(2),
    is_principal boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.produits_barcodes OWNER TO postgres;

--
-- Name: produits_barcodes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.produits_barcodes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.produits_barcodes_id_seq OWNER TO postgres;

--
-- Name: produits_barcodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.produits_barcodes_id_seq OWNED BY public.produits_barcodes.id;


--
-- Name: produits_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.produits_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.produits_id_seq OWNER TO postgres;

--
-- Name: produits_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.produits_id_seq OWNED BY public.produits.id;


--
-- Name: v_stock_courant; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_stock_courant AS
 SELECT p.id,
    p.nom,
    p.categorie,
    p.prix_achat,
    p.prix_vente,
    p.tva,
    p.seuil_alerte,
    p.actif,
    COALESCE(sum(
        CASE
            WHEN (m.type = ANY (ARRAY['ENTREE'::public.type_mouvement, 'INVENTAIRE'::public.type_mouvement, 'TRANSFERT'::public.type_mouvement])) THEN m.quantite
            WHEN (m.type = 'SORTIE'::public.type_mouvement) THEN (- m.quantite)
            ELSE (0)::numeric
        END), (0)::numeric) AS stock
   FROM (public.produits p
     LEFT JOIN public.mouvements_stock m ON ((m.produit_id = p.id)))
  GROUP BY p.id, p.nom, p.categorie, p.prix_achat, p.prix_vente, p.tva, p.seuil_alerte, p.actif
  ORDER BY p.nom;


ALTER VIEW public.v_stock_courant OWNER TO postgres;

--
-- Name: stock_courant; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.stock_courant AS
 SELECT id,
    nom,
    categorie,
    prix_achat,
    prix_vente,
    tva,
    seuil_alerte,
    actif,
    stock
   FROM public.v_stock_courant;


ALTER VIEW public.stock_courant OWNER TO postgres;

--
-- Name: v_alertes_rupture; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_alertes_rupture AS
 SELECT id,
    nom,
    categorie,
    (stock)::numeric(12,3) AS stock,
    seuil_alerte
   FROM public.v_stock_courant s
  WHERE (((stock)::numeric(12,3) <= COALESCE(seuil_alerte, (0)::numeric)) AND (actif = true))
  ORDER BY ((stock)::numeric(12,3));


ALTER VIEW public.v_alertes_rupture OWNER TO postgres;

--
-- Name: v_inventaire_negatif; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_inventaire_negatif AS
 SELECT id,
    nom,
    categorie,
    prix_achat,
    prix_vente,
    tva,
    seuil_alerte,
    actif,
    stock
   FROM public.v_stock_courant
  WHERE (stock < (0)::numeric)
  ORDER BY stock;


ALTER VIEW public.v_inventaire_negatif OWNER TO postgres;

--
-- Name: v_mouvements_recents; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_mouvements_recents AS
 SELECT m.id,
    m.date_mvt,
    m.type,
    m.quantite,
    m.source,
    p.id AS produit_id,
    p.nom,
    p.categorie
   FROM (public.mouvements_stock m
     JOIN public.produits p ON ((p.id = m.produit_id)))
  ORDER BY m.date_mvt DESC
 LIMIT 500;


ALTER VIEW public.v_mouvements_recents OWNER TO postgres;

--
-- Name: v_produits_codes; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_produits_codes AS
 SELECT p.id,
    p.nom,
    p.categorie,
    p.prix_achat,
    p.prix_vente,
    p.tva,
    p.actif,
    COALESCE(string_agg(pb.code, ', '::text ORDER BY pb.is_principal DESC, pb.code), ''::text) AS codes
   FROM (public.produits p
     LEFT JOIN public.produits_barcodes pb ON ((pb.produit_id = p.id)))
  GROUP BY p.id, p.nom, p.categorie, p.prix_achat, p.prix_vente, p.tva, p.actif
  ORDER BY p.nom;


ALTER VIEW public.v_produits_codes OWNER TO postgres;

--
-- Name: v_prod_barcodes; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_prod_barcodes AS
 SELECT id,
    nom,
    categorie,
    prix_achat,
    prix_vente,
    tva,
    actif,
    codes
   FROM public.v_produits_codes;


ALTER VIEW public.v_prod_barcodes OWNER TO postgres;

--
-- Name: v_produits_sans_barcode; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_produits_sans_barcode AS
 SELECT p.id,
    p.nom,
    p.categorie,
    p.prix_achat,
    p.prix_vente,
    p.tva,
    p.seuil_alerte,
    p.actif,
    p.stock_actuel,
    p.created_at,
    p.updated_at
   FROM (public.produits p
     LEFT JOIN public.produits_barcodes pb ON ((pb.produit_id = p.id)))
  WHERE (pb.id IS NULL)
  ORDER BY p.nom;


ALTER VIEW public.v_produits_sans_barcode OWNER TO postgres;

--
-- Name: v_rotation_30j; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_rotation_30j AS
 SELECT p.id,
    p.nom,
    sum(
        CASE
            WHEN (m.type = 'ENTREE'::public.type_mouvement) THEN m.quantite
            ELSE (0)::numeric
        END) AS entrees_30j,
    sum(
        CASE
            WHEN (m.type = 'SORTIE'::public.type_mouvement) THEN m.quantite
            ELSE (0)::numeric
        END) AS sorties_30j
   FROM (public.produits p
     LEFT JOIN public.mouvements_stock m ON (((m.produit_id = p.id) AND (m.date_mvt >= (now() - '30 days'::interval)))))
  GROUP BY p.id, p.nom
  ORDER BY (sum(
        CASE
            WHEN (m.type = 'SORTIE'::public.type_mouvement) THEN m.quantite
            ELSE (0)::numeric
        END)) DESC NULLS LAST;


ALTER VIEW public.v_rotation_30j OWNER TO postgres;

--
-- Name: v_stock_produits; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_stock_produits AS
 SELECT id,
    nom,
    categorie,
    prix_vente,
    tva,
    seuil_alerte,
    stock_actuel AS quantite_stock
   FROM public.produits p
  WHERE (actif = true);


ALTER VIEW public.v_stock_produits OWNER TO postgres;

--
-- Name: v_top_ventes_30j; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_top_ventes_30j AS
 SELECT p.id,
    p.nom,
    sum(
        CASE
            WHEN (m.type = 'SORTIE'::public.type_mouvement) THEN m.quantite
            ELSE (0)::numeric
        END) AS qte_sorties_30j
   FROM (public.produits p
     LEFT JOIN public.mouvements_stock m ON (((m.produit_id = p.id) AND (m.date_mvt >= (now() - '30 days'::interval)))))
  GROUP BY p.id, p.nom
  ORDER BY (sum(
        CASE
            WHEN (m.type = 'SORTIE'::public.type_mouvement) THEN m.quantite
            ELSE (0)::numeric
        END)) DESC NULLS LAST;


ALTER VIEW public.v_top_ventes_30j OWNER TO postgres;

--
-- Name: v_valorisation_stock; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.v_valorisation_stock AS
 SELECT id,
    nom,
    categorie,
    stock,
    prix_achat,
    round((stock * COALESCE(prix_achat, (0)::numeric)), 2) AS valeur_achat
   FROM public.v_stock_courant s
  WHERE (stock > (0)::numeric)
  ORDER BY (round((stock * COALESCE(prix_achat, (0)::numeric)), 2)) DESC;


ALTER VIEW public.v_valorisation_stock OWNER TO postgres;

--
-- Name: mouvements_stock id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mouvements_stock ALTER COLUMN id SET DEFAULT nextval('public.mouvements_stock_id_seq'::regclass);


--
-- Name: produits id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produits ALTER COLUMN id SET DEFAULT nextval('public.produits_id_seq'::regclass);


--
-- Name: produits_barcodes id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produits_barcodes ALTER COLUMN id SET DEFAULT nextval('public.produits_barcodes_id_seq'::regclass);


--
-- Data for Name: mouvements_stock; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mouvements_stock (id, produit_id, type, quantite, source, date_mvt, created_at) FROM stdin;
1	2	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
2	3	ENTREE	2.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
3	13	ENTREE	2.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
4	18	ENTREE	3.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
5	3	ENTREE	3.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
6	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
7	19	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
8	21	ENTREE	2.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
9	3	ENTREE	2.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
10	3	ENTREE	2.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
11	22	ENTREE	2.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
12	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
13	23	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
14	44	ENTREE	10.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
15	3	ENTREE	10.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
16	45	ENTREE	5.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
17	3	ENTREE	5.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
18	3	ENTREE	9.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
19	46	ENTREE	9.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
20	47	ENTREE	7.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
21	3	ENTREE	7.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
22	48	ENTREE	18.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
23	3	ENTREE	18.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
24	51	ENTREE	8.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
25	3	ENTREE	8.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
26	52	ENTREE	4.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
27	3	ENTREE	4.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
28	3	ENTREE	5.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
29	3	ENTREE	5.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
30	68	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
31	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
32	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
33	70	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
34	3	ENTREE	8.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
35	71	ENTREE	8.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
36	3	ENTREE	26.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
37	72	ENTREE	26.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
38	73	ENTREE	7.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
39	3	ENTREE	7.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
40	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
41	77	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
42	78	ENTREE	6.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
43	3	ENTREE	6.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
44	3	ENTREE	7.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
45	3	ENTREE	7.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
46	80	ENTREE	3.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
47	3	ENTREE	3.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
48	81	ENTREE	7.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
49	3	ENTREE	7.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
50	82	ENTREE	11.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
51	3	ENTREE	11.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
52	3	ENTREE	2.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
53	83	ENTREE	2.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
54	84	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
55	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
56	3	ENTREE	6.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
57	85	ENTREE	6.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
58	86	ENTREE	4.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
59	3	ENTREE	4.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
60	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
61	87	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
62	3	ENTREE	2.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
63	88	ENTREE	2.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
64	89	ENTREE	2.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
65	3	ENTREE	2.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
66	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
67	90	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
68	91	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
69	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
70	3	ENTREE	2.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
71	92	ENTREE	2.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
72	3	ENTREE	2.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
73	94	ENTREE	2.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
74	3	ENTREE	5.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
75	3	ENTREE	5.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
76	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
77	126	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
78	3	ENTREE	2.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
79	131	ENTREE	2.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
80	3	ENTREE	8.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
81	3	ENTREE	8.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
82	3	ENTREE	17.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
83	154	ENTREE	17.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
84	155	ENTREE	2.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
85	3	ENTREE	2.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
86	3	ENTREE	3.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
87	157	ENTREE	3.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
88	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
89	158	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
90	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
91	161	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
92	3	ENTREE	4.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
93	3	ENTREE	4.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
94	162	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
95	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
96	3	ENTREE	2.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
97	166	ENTREE	2.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
98	167	ENTREE	3.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
99	3	ENTREE	3.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
100	3	ENTREE	2.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
101	168	ENTREE	2.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
102	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
103	169	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
104	3	ENTREE	2.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
105	3	ENTREE	2.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
106	170	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
107	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
108	172	ENTREE	3.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
109	3	ENTREE	3.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
110	3	ENTREE	4.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
111	173	ENTREE	4.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
112	3	ENTREE	3.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
113	175	ENTREE	3.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
114	3	ENTREE	6.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
115	176	ENTREE	6.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
116	177	ENTREE	5.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
117	3	ENTREE	5.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
118	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
119	178	ENTREE	5.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
120	3	ENTREE	5.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
121	180	ENTREE	6.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
122	3	ENTREE	6.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
123	181	ENTREE	10.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
124	3	ENTREE	10.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
125	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
126	182	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
127	3	ENTREE	3.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
128	183	ENTREE	3.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
129	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
130	184	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
131	3	ENTREE	10.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
132	201	ENTREE	10.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
133	205	ENTREE	3.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
134	3	ENTREE	3.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
135	216	ENTREE	2.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
136	3	ENTREE	2.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
137	217	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
138	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
139	218	ENTREE	2.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
140	3	ENTREE	2.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
141	3	ENTREE	3.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
142	225	ENTREE	3.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
143	226	ENTREE	2.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
144	3	ENTREE	2.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
145	227	ENTREE	2.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
146	3	ENTREE	2.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
147	231	ENTREE	5.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
148	3	ENTREE	5.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
149	241	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
150	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
151	3	ENTREE	3.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
152	242	ENTREE	3.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
153	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
154	244	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
155	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
156	246	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
157	247	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
158	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
159	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
160	252	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
161	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
162	3	ENTREE	1.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
163	3	ENTREE	4.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
164	3	ENTREE	4.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
165	3	ENTREE	2.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
166	3	ENTREE	2.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
167	256	ENTREE	2.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
168	3	ENTREE	2.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
169	3	ENTREE	3.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
170	3	ENTREE	3.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
171	3	ENTREE	2.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
172	3	ENTREE	4.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
173	3	ENTREE	4.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
174	262	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
175	263	ENTREE	2.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
176	264	ENTREE	4.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
177	265	ENTREE	3.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
178	3	ENTREE	3.000	Import facture - code nan	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
179	281	ENTREE	11.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
180	284	ENTREE	7.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
181	287	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
182	288	ENTREE	1.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
183	292	ENTREE	2.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
184	293	ENTREE	2.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
185	294	ENTREE	2.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
186	295	ENTREE	3.000	Import facture - création	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
187	297	ENTREE	5.000	Import facture - création	2025-10-30 12:05:49.521322	2025-10-30 12:05:49.521322
188	298	ENTREE	25.000	Import facture - création	2025-10-30 12:05:49.521322	2025-10-30 12:05:49.521322
189	299	ENTREE	15.000	Import facture - création	2025-10-30 12:05:49.521322	2025-10-30 12:05:49.521322
190	300	ENTREE	19.000	Import facture - création	2025-10-30 12:05:49.521322	2025-10-30 12:05:49.521322
191	301	ENTREE	4.000	Import facture - création	2025-10-30 12:05:49.521322	2025-10-30 12:05:49.521322
192	302	ENTREE	29.000	Import facture - création	2025-10-30 12:05:49.521322	2025-10-30 12:05:49.521322
193	303	ENTREE	6.000	Import facture - création	2025-10-30 12:05:49.521322	2025-10-30 12:05:49.521322
194	304	ENTREE	3.000	Import facture - création	2025-10-30 12:05:49.521322	2025-10-30 12:05:49.521322
195	305	ENTREE	2.000	Import facture - création	2025-10-30 12:05:49.521322	2025-10-30 12:05:49.521322
196	308	ENTREE	7.000	Import facture - création	2025-10-30 12:05:49.521322	2025-10-30 12:05:49.521322
197	309	ENTREE	22.000	Import facture - création	2025-10-30 12:06:22.270134	2025-10-30 12:06:22.270134
198	310	ENTREE	3.000	Import facture - création	2025-10-30 12:06:22.270134	2025-10-30 12:06:22.270134
199	311	ENTREE	8.000	Import facture - création	2025-10-30 12:06:22.270134	2025-10-30 12:06:22.270134
200	312	ENTREE	7.000	Import facture - création	2025-10-30 12:06:22.270134	2025-10-30 12:06:22.270134
201	313	ENTREE	8.000	Import facture - création	2025-10-30 12:06:22.270134	2025-10-30 12:06:22.270134
202	314	ENTREE	12.000	Import facture - création	2025-10-30 12:06:22.270134	2025-10-30 12:06:22.270134
203	315	ENTREE	530.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
204	316	ENTREE	160.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
205	317	ENTREE	63.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
206	318	ENTREE	17.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
207	319	ENTREE	58.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
208	320	ENTREE	60.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
209	321	ENTREE	48.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
210	322	ENTREE	29.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
211	323	ENTREE	13.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
212	324	ENTREE	12.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
213	325	ENTREE	14.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
214	326	ENTREE	12.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
215	329	ENTREE	19.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
216	330	ENTREE	15.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
217	331	ENTREE	20.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
218	332	ENTREE	13.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
219	334	ENTREE	13.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
220	336	ENTREE	7.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
221	337	ENTREE	3.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
222	338	ENTREE	3.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
223	339	ENTREE	2.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
224	340	ENTREE	2.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
225	341	ENTREE	7.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
226	342	ENTREE	7.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
227	343	ENTREE	4.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
228	345	ENTREE	6.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
229	346	ENTREE	5.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
230	347	ENTREE	5.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
231	348	ENTREE	4.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
232	349	ENTREE	22.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
233	350	ENTREE	15.000	Import facture - création	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
234	352	ENTREE	377.000	Import facture - création	2025-10-30 12:07:11.398554	2025-10-30 12:07:11.398554
235	353	ENTREE	8.000	Import facture - création	2025-10-30 12:07:11.398554	2025-10-30 12:07:11.398554
236	315	ENTREE	442.000	Import facture - code 5010327325125	2025-10-30 12:07:45.054577	2025-10-30 12:07:45.054577
237	316	ENTREE	190.000	Import facture - code 3211200184743	2025-10-30 12:07:45.054577	2025-10-30 12:07:45.054577
238	317	ENTREE	70.000	Import facture - code 3439495507928	2025-10-30 12:07:45.054577	2025-10-30 12:07:45.054577
239	354	ENTREE	30.000	Import facture - création	2025-10-30 12:07:45.054577	2025-10-30 12:07:45.054577
240	355	ENTREE	27.000	Import facture - création	2025-10-30 12:07:45.054577	2025-10-30 12:07:45.054577
241	356	ENTREE	5.000	Import facture - création	2025-10-30 12:07:45.054577	2025-10-30 12:07:45.054577
242	357	ENTREE	5.000	Import facture - création	2025-10-30 12:07:45.054577	2025-10-30 12:07:45.054577
243	358	ENTREE	10.000	Import facture - création	2025-10-30 12:07:45.054577	2025-10-30 12:07:45.054577
244	359	ENTREE	20.000	Import facture - création	2025-10-30 12:07:45.054577	2025-10-30 12:07:45.054577
245	361	ENTREE	24.000	Import facture - création	2025-10-30 12:07:45.054577	2025-10-30 12:07:45.054577
246	310	ENTREE	3.000	Import facture	2025-10-30 12:08:00.448408	2025-10-30 12:08:00.448408
247	363	ENTREE	10.000	Import facture - création	2025-10-30 12:08:00.448408	2025-10-30 12:08:00.448408
248	315	ENTREE	451.000	Import facture - code 5010327325125	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
249	365	ENTREE	7.000	Import facture - création	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
250	366	ENTREE	84.000	Import facture - création	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
251	316	ENTREE	128.000	Import facture - code 3211200184743	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
252	367	ENTREE	17.000	Import facture - création	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
253	368	ENTREE	39.000	Import facture - création	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
254	369	ENTREE	32.000	Import facture - création	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
255	370	ENTREE	16.000	Import facture - création	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
256	371	ENTREE	238.000	Import facture - création	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
257	320	ENTREE	20.000	Import facture - code 5410228203582	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
258	354	ENTREE	30.000	Import facture - code 5410228223580	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
259	372	ENTREE	5.000	Import facture - création	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
260	321	ENTREE	26.000	Import facture - code 3155930400530	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
261	373	ENTREE	17.000	Import facture - création	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
262	374	ENTREE	19.000	Import facture - création	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
263	375	ENTREE	7.000	Import facture - création	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
264	376	ENTREE	8.000	Import facture - création	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
265	377	ENTREE	15.000	Import facture - création	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
266	378	ENTREE	22.000	Import facture - création	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
267	379	ENTREE	22.000	Import facture - création	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
268	380	ENTREE	13.000	Import facture - création	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
269	381	ENTREE	10.000	Import facture - création	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
270	382	ENTREE	8.000	Import facture - création	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
271	383	ENTREE	14.000	Import facture - création	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
272	384	ENTREE	6.000	Import facture - création	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
273	385	ENTREE	10.000	Import facture - création	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
274	315	ENTREE	451.000	Import facture - code 5010327325125	2025-10-30 12:08:39.842775	2025-10-30 12:08:39.842775
275	316	ENTREE	64.000	Import facture - code 3211200184743	2025-10-30 12:08:39.842775	2025-10-30 12:08:39.842775
276	367	ENTREE	17.000	Import facture - code 3175529657725	2025-10-30 12:08:39.842775	2025-10-30 12:08:39.842775
277	368	ENTREE	47.000	Import facture - code 3259354102060	2025-10-30 12:08:39.842775	2025-10-30 12:08:39.842775
278	369	ENTREE	16.000	Import facture - code 03179077103147	2025-10-30 12:08:39.842775	2025-10-30 12:08:39.842775
279	370	ENTREE	16.000	Import facture - code 03179077103154	2025-10-30 12:08:39.842775	2025-10-30 12:08:39.842775
280	386	ENTREE	33.000	Import facture - création	2025-10-30 12:08:39.842775	2025-10-30 12:08:39.842775
281	387	ENTREE	16.000	Import facture - création	2025-10-30 12:08:39.842775	2025-10-30 12:08:39.842775
282	388	ENTREE	13.000	Import facture - création	2025-10-30 12:08:39.842775	2025-10-30 12:08:39.842775
283	389	ENTREE	5.000	Import facture - création	2025-10-30 12:08:39.842775	2025-10-30 12:08:39.842775
284	390	ENTREE	5.000	Import facture - création	2025-10-30 12:08:39.842775	2025-10-30 12:08:39.842775
285	381	ENTREE	10.000	Import facture - code 3439495111699	2025-10-30 12:08:39.842775	2025-10-30 12:08:39.842775
286	391	ENTREE	9.000	Import facture - création	2025-10-30 12:08:39.842775	2025-10-30 12:08:39.842775
287	392	ENTREE	4.000	Import facture - création	2025-10-30 12:08:39.842775	2025-10-30 12:08:39.842775
288	393	ENTREE	11.000	Import facture - création	2025-10-30 12:08:39.842775	2025-10-30 12:08:39.842775
289	345	ENTREE	6.000	Import facture - code 3439496604015	2025-10-30 12:08:39.842775	2025-10-30 12:08:39.842775
290	346	ENTREE	5.000	Import facture - code 3439496603995	2025-10-30 12:08:39.842775	2025-10-30 12:08:39.842775
291	347	ENTREE	5.000	Import facture - code 3439496604008	2025-10-30 12:08:39.842775	2025-10-30 12:08:39.842775
292	394	ENTREE	17.000	Import facture - création	2025-10-30 12:08:39.842775	2025-10-30 12:08:39.842775
293	361	ENTREE	25.000	Import facture - code 3439496810997	2025-10-30 12:08:39.842775	2025-10-30 12:08:39.842775
294	395	ENTREE	86.000	Import facture - création	2025-10-30 12:09:02.576379	2025-10-30 12:09:02.576379
295	396	ENTREE	387.000	Import facture - création	2025-10-30 12:09:02.576379	2025-10-30 12:09:02.576379
296	397	ENTREE	20.000	Import facture - création	2025-10-30 12:09:02.576379	2025-10-30 12:09:02.576379
297	398	ENTREE	10.000	Import facture - création	2025-10-30 12:09:02.576379	2025-10-30 12:09:02.576379
298	318	ENTREE	14.000	Import facture - code 3259356633067	2025-10-30 12:09:02.576379	2025-10-30 12:09:02.576379
299	399	ENTREE	226.000	Import facture - création	2025-10-30 12:09:02.576379	2025-10-30 12:09:02.576379
300	371	ENTREE	79.000	Import facture - code 3439495600360	2025-10-30 12:09:02.576379	2025-10-30 12:09:02.576379
301	315	ENTREE	451.000	Import facture - code 5010327325125	2025-10-30 12:09:38.699924	2025-10-30 12:09:38.699924
302	400	ENTREE	103.000	Import facture - création	2025-10-30 12:09:38.699924	2025-10-30 12:09:38.699924
303	366	ENTREE	47.000	Import facture - code 3257150100228	2025-10-30 12:09:38.699924	2025-10-30 12:09:38.699924
304	316	ENTREE	128.000	Import facture - code 3211200184743	2025-10-30 12:09:38.699924	2025-10-30 12:09:38.699924
305	368	ENTREE	47.000	Import facture - code 3259354102060	2025-10-30 12:09:38.699924	2025-10-30 12:09:38.699924
306	386	ENTREE	33.000	Import facture - code 3439495501568	2025-10-30 12:09:38.699924	2025-10-30 12:09:38.699924
307	389	ENTREE	5.000	Import facture - code 03439495113495	2025-10-30 12:09:38.699924	2025-10-30 12:09:38.699924
308	356	ENTREE	5.000	Import facture - code 3439496607221	2025-10-30 12:09:38.699924	2025-10-30 12:09:38.699924
309	401	ENTREE	2.000	Import facture - création	2025-10-30 12:09:38.699924	2025-10-30 12:09:38.699924
310	361	ENTREE	25.000	Import facture - code 3439496810997	2025-10-30 12:09:38.699924	2025-10-30 12:09:38.699924
311	402	ENTREE	85.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
312	315	ENTREE	406.000	Import facture - code 5010327325125	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
313	403	ENTREE	7.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
314	404	ENTREE	7.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
315	405	ENTREE	7.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
316	406	ENTREE	22.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
317	407	ENTREE	76.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
318	408	ENTREE	10.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
319	409	ENTREE	14.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
320	410	ENTREE	14.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
321	316	ENTREE	192.000	Import facture - code 3211200184743	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
322	411	ENTREE	25.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
323	367	ENTREE	17.000	Import facture - code 3175529657725	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
324	369	ENTREE	32.000	Import facture - code 03179077103147	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
325	412	ENTREE	35.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
326	413	ENTREE	20.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
327	414	ENTREE	11.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
328	397	ENTREE	40.000	Import facture - code 3439495508345	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
329	370	ENTREE	32.000	Import facture - code 03179077103154	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
330	415	ENTREE	21.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
331	373	ENTREE	17.000	Import facture - code 3439495405064	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
332	374	ENTREE	17.000	Import facture - code 3439495403794	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
333	416	ENTREE	6.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
334	375	ENTREE	7.000	Import facture - code 3439495405040	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
335	417	ENTREE	8.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
336	376	ENTREE	8.000	Import facture - code 3439495406320	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
337	377	ENTREE	15.000	Import facture - code 3439495406368	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
338	418	ENTREE	44.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
339	419	ENTREE	12.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
340	391	ENTREE	9.000	Import facture - code 3439495102796	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
341	382	ENTREE	8.000	Import facture - code 4337182248705	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
342	420	ENTREE	64.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
343	330	ENTREE	15.000	Import facture - code 5000159555722	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
344	383	ENTREE	14.000	Import facture - code 3281130011129	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
345	421	ENTREE	15.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
346	422	ENTREE	13.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
347	423	ENTREE	14.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
348	424	ENTREE	12.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
349	425	ENTREE	11.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
350	426	ENTREE	10.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
351	427	ENTREE	14.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
352	336	ENTREE	8.000	Import facture - code 8445290872036	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
353	356	ENTREE	5.000	Import facture - code 3439496607221	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
354	357	ENTREE	5.000	Import facture - code 3439496000657	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
355	345	ENTREE	6.000	Import facture - code 3439496604015	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
356	428	ENTREE	4.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
357	429	ENTREE	4.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
358	430	ENTREE	8.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
359	431	ENTREE	9.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
360	432	ENTREE	2.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
361	433	ENTREE	6.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
362	435	ENTREE	14.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
363	394	ENTREE	17.000	Import facture - code 4337182138341	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
364	436	ENTREE	8.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
365	437	ENTREE	7.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
366	438	ENTREE	6.000	Import facture - création	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
367	315	ENTREE	225.000	Import facture - code 5010327325125	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
368	439	ENTREE	97.000	Import facture - création	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
369	440	ENTREE	123.000	Import facture - création	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
370	316	ENTREE	64.000	Import facture - code 3211200184743	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
371	441	ENTREE	13.000	Import facture - création	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
372	367	ENTREE	17.000	Import facture - code 3175529657725	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
373	369	ENTREE	14.000	Import facture - code 03179077103147	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
374	397	ENTREE	20.000	Import facture - code 3439495508345	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
375	370	ENTREE	29.000	Import facture - code 03179077103154	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
376	399	ENTREE	221.000	Import facture - code 3049614222252	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
377	442	ENTREE	112.000	Import facture - création	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
378	354	ENTREE	30.000	Import facture - code 5410228223580	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
379	352	ENTREE	194.000	Import facture - code 3119783018823	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
380	443	ENTREE	12.000	Import facture - création	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
381	444	ENTREE	19.000	Import facture - création	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
382	445	ENTREE	7.000	Import facture - création	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
383	446	ENTREE	10.000	Import facture - création	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
384	447	ENTREE	7.000	Import facture - création	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
385	448	ENTREE	7.000	Import facture - création	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
386	449	ENTREE	7.000	Import facture - création	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
387	450	ENTREE	7.000	Import facture - création	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
388	451	ENTREE	18.000	Import facture - création	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
389	383	ENTREE	14.000	Import facture - code 3281130011129	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
390	345	ENTREE	6.000	Import facture - code 3439496604015	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
391	346	ENTREE	5.000	Import facture - code 3439496603995	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
392	361	ENTREE	25.000	Import facture - code 3439496810997	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
393	452	ENTREE	18.000	Import facture - création	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
394	453	ENTREE	30.000	Import facture - création	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
395	315	ENTREE	451.000	Import facture - code 5010327325125	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
396	454	ENTREE	125.000	Import facture - création	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
397	440	ENTREE	103.000	Import facture - code 5000267024325	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
398	455	ENTREE	337.000	Import facture - création	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
399	456	ENTREE	21.000	Import facture - création	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
400	457	ENTREE	53.000	Import facture - création	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
401	458	ENTREE	23.000	Import facture - création	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
402	459	ENTREE	267.000	Import facture - création	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
403	460	ENTREE	4.000	Import facture - création	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
404	461	ENTREE	4.000	Import facture - création	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
405	462	ENTREE	4.000	Import facture - création	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
406	354	ENTREE	45.000	Import facture - code 5410228223580	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
407	372	ENTREE	5.000	Import facture - code 3080210003425	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
408	418	ENTREE	49.000	Import facture - code 3075711382018	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
409	383	ENTREE	14.000	Import facture - code 3281130011129	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
410	345	ENTREE	6.000	Import facture - code 3439496604015	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
411	346	ENTREE	5.000	Import facture - code 3439496603995	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
412	347	ENTREE	5.000	Import facture - code 3439496604008	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
413	385	ENTREE	10.000	Import facture - code 3439496807805	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
414	463	ENTREE	23.000	Import facture - création	2025-10-30 12:11:25.7753	2025-10-30 12:11:25.7753
415	464	ENTREE	20.000	Import facture - création	2025-10-30 12:11:25.7753	2025-10-30 12:11:25.7753
416	465	ENTREE	22.000	Import facture - création	2025-10-30 12:11:25.7753	2025-10-30 12:11:25.7753
417	466	ENTREE	23.000	Import facture - création	2025-10-30 12:11:25.7753	2025-10-30 12:11:25.7753
418	321	ENTREE	26.000	Import facture - code 3155930400530	2025-10-30 12:11:25.7753	2025-10-30 12:11:25.7753
419	467	ENTREE	4.000	Import facture - création	2025-10-30 12:11:25.7753	2025-10-30 12:11:25.7753
420	468	ENTREE	4.000	Import facture - création	2025-10-30 12:11:25.7753	2025-10-30 12:11:25.7753
421	469	ENTREE	69.000	Import facture - création	2025-10-30 12:11:39.640331	2025-10-30 12:11:39.640331
422	470	ENTREE	64.000	Import facture - création	2025-10-30 12:11:39.640331	2025-10-30 12:11:39.640331
423	315	ENTREE	135.000	Import facture - code 5010327325125	2025-10-30 12:11:39.640331	2025-10-30 12:11:39.640331
424	471	ENTREE	103.000	Import facture - création	2025-10-30 12:11:39.640331	2025-10-30 12:11:39.640331
425	472	ENTREE	34.000	Import facture - création	2025-10-30 12:11:39.640331	2025-10-30 12:11:39.640331
426	455	ENTREE	255.000	Import facture - code 05000299225332	2025-10-30 12:11:39.640331	2025-10-30 12:11:39.640331
427	473	ENTREE	149.000	Import facture - création	2025-10-30 12:11:39.640331	2025-10-30 12:11:39.640331
428	474	ENTREE	210.000	Import facture - création	2025-10-30 12:11:39.640331	2025-10-30 12:11:39.640331
429	475	ENTREE	115.000	Import facture - création	2025-10-30 12:11:39.640331	2025-10-30 12:11:39.640331
430	477	ENTREE	5.000	Import facture - création	2025-10-30 12:11:39.640331	2025-10-30 12:11:39.640331
431	439	ENTREE	97.000	Import facture - code 3099873045864	2025-10-30 12:11:53.816872	2025-10-30 12:11:53.816872
432	365	ENTREE	7.000	Import facture - code 3147697510607	2025-10-30 12:11:53.816872	2025-10-30 12:11:53.816872
433	365	ENTREE	7.000	Import facture	2025-10-30 12:11:53.816872	2025-10-30 12:11:53.816872
434	409	ENTREE	29.000	Import facture - code 3147690093602	2025-10-30 12:11:53.816872	2025-10-30 12:11:53.816872
435	410	ENTREE	29.000	Import facture - code 3147690094708	2025-10-30 12:11:53.816872	2025-10-30 12:11:53.816872
436	320	ENTREE	30.000	Import facture - code 5410228203582	2025-10-30 12:11:53.816872	2025-10-30 12:11:53.816872
437	372	ENTREE	5.000	Import facture - code 3080210003425	2025-10-30 12:11:53.816872	2025-10-30 12:11:53.816872
438	478	ENTREE	20.000	Import facture - création	2025-10-30 12:11:53.816872	2025-10-30 12:11:53.816872
439	321	ENTREE	79.000	Import facture - code 3155930400530	2025-10-30 12:11:53.816872	2025-10-30 12:11:53.816872
440	322	ENTREE	30.000	Import facture - code 3119783016690	2025-10-30 12:11:53.816872	2025-10-30 12:11:53.816872
441	479	ENTREE	73.000	Import facture - création	2025-10-30 12:11:53.816872	2025-10-30 12:11:53.816872
442	480	ENTREE	51.000	Import facture - création	2025-10-30 12:11:53.816872	2025-10-30 12:11:53.816872
443	481	ENTREE	49.000	Import facture - création	2025-10-30 12:11:53.816872	2025-10-30 12:11:53.816872
444	379	ENTREE	31.000	Import facture - code 8002270116551	2025-10-30 12:11:53.816872	2025-10-30 12:11:53.816872
445	482	ENTREE	13.000	Import facture - création	2025-10-30 12:11:53.816872	2025-10-30 12:11:53.816872
446	316	ENTREE	128.000	Import facture - code 3211200184743	2025-10-30 12:12:16.376798	2025-10-30 12:12:16.376798
447	399	ENTREE	221.000	Import facture - code 3049614222252	2025-10-30 12:12:16.376798	2025-10-30 12:12:16.376798
448	354	ENTREE	60.000	Import facture - code 5410228223580	2025-10-30 12:12:16.376798	2025-10-30 12:12:16.376798
449	352	ENTREE	77.000	Import facture - code 3119783018823	2025-10-30 12:12:16.376798	2025-10-30 12:12:16.376798
450	372	ENTREE	5.000	Import facture - code 3080210003425	2025-10-30 12:12:16.376798	2025-10-30 12:12:16.376798
451	381	ENTREE	10.000	Import facture - code 3439495111699	2025-10-30 12:12:16.376798	2025-10-30 12:12:16.376798
452	391	ENTREE	9.000	Import facture - code 3439495102796	2025-10-30 12:12:16.376798	2025-10-30 12:12:16.376798
453	336	ENTREE	8.000	Import facture - code 8445290872036	2025-10-30 12:12:16.376798	2025-10-30 12:12:16.376798
454	361	ENTREE	25.000	Import facture - code 3439496810997	2025-10-30 12:12:16.376798	2025-10-30 12:12:16.376798
455	316	ENTREE	64.000	Import facture - code 3211200184743	2025-10-30 12:12:27.379196	2025-10-30 12:12:27.379196
456	381	ENTREE	10.000	Import facture - code 3439495111699	2025-10-30 12:12:27.379196	2025-10-30 12:12:27.379196
457	359	ENTREE	20.000	Import facture - code 4337182249290	2025-10-30 12:12:27.379196	2025-10-30 12:12:27.379196
\.


--
-- Data for Name: produits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.produits (id, nom, categorie, prix_achat, prix_vente, tva, seuil_alerte, actif, stock_actuel, created_at, updated_at) FROM stdin;
1	BELLE F - MAQUEREAUX FLT 169G	Boissons	0.00	1.99	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
2	JW RED LABEL1L	Autre	0.00	27.90	20.00	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
297	SCE BIGY BURGER	Autre	9.00	9.00	20.00	0.000	t	5.000	2025-10-30 12:05:49.521322	2025-10-30 12:05:49.521322
298	SUCRE SOLNEIGE 5KG ST LOUIS 25 490 1	Autre	1.00	1.00	20.00	0.000	t	25.000	2025-10-30 12:05:49.521322	2025-10-30 12:05:49.521322
299	MC BOUCHEE RESTAU MGV X48 0 313 48	Autre	1.00	1.00	20.00	0.000	t	15.000	2025-10-30 12:05:49.521322	2025-10-30 12:05:49.521322
4	$8717438769837	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
300	PIDY 96 MINI TARTELETTES FINES NEUTRE BORD DROIT 19 890 1	Autre	1.00	1.00	20.00	0.000	t	19.000	2025-10-30 12:05:49.521322	2025-10-30 12:05:49.521322
301	NAPPAGE NEUTRE 0 9KG STAND.-VAR. 4 350 1	Autre	1.00	1.00	20.00	0.000	t	4.000	2025-10-30 12:05:49.521322	2025-10-30 12:05:49.521322
302	CREME UHT 35% 1L MC BK AP 4 898 6	Autre	1.00	1.00	20.00	0.000	t	29.000	2025-10-30 12:05:49.521322	2025-10-30 12:05:49.521322
303	PAST 8/12K BOX35 MA MAROC 6 490 1	Autre	1.00	1.00	20.00	0.000	t	6.000	2025-10-30 12:05:49.521322	2025-10-30 12:05:49.521322
304	40 VERRINE 4 CL PS CRISTAL 1 800 1	Autre	2.00	2.00	20.00	0.000	t	3.000	2025-10-30 12:05:49.521322	2025-10-30 12:05:49.521322
305	500 BROCHETTE 15CM 2 510 1	Autre	1.00	1.00	20.00	0.000	t	2.000	2025-10-30 12:05:49.521322	2025-10-30 12:05:49.521322
306	MPRO	Autre	5.00	5.00	20.00	0.000	t	0.000	2025-10-30 12:05:49.521322	2025-10-30 12:05:49.521322
307	MPRO 25 BARQ ALU+COUV	Autre	21.00	21.00	20.00	0.000	t	0.000	2025-10-30 12:05:49.521322	2025-10-30 12:05:49.521322
308	MPRO 50 BARQ ALU+COUV	Autre	8.00	8.00	20.00	0.000	t	7.000	2025-10-30 12:05:49.521322	2025-10-30 12:05:49.521322
309	MINI BURGER 8X24G DULCESOL 1 630 1	Autre	14.00	14.00	20.00	0.000	t	22.000	2025-10-30 12:06:22.270134	2025-10-30 12:06:22.270134
311	PAST 8/12K BOX35 MA MAROC 8 990 1	Autre	1.00	1.00	20.00	0.000	t	8.000	2025-10-30 12:06:22.270134	2025-10-30 12:06:22.270134
312	MEL CJ MC C.750/	Autre	9.00	9.00	5.50	0.000	t	7.000	2025-10-30 12:06:22.270134	2025-10-30 12:06:22.270134
313	SAL ICEBERG MC DEMIPAL PC	Autre	2.00	2.00	20.00	0.000	t	8.000	2025-10-30 12:06:22.270134	2025-10-30 12:06:22.270134
314	45 VERRINE 7 CL PS CRISTAL 4 280 1	Autre	3.00	3.00	20.00	0.000	t	12.000	2025-10-30 12:06:22.270134	2025-10-30 12:06:22.270134
333	BARRE MGV KER SUZEL	Autre	8.00	8.00	20.00	0.000	t	0.000	2025-10-30 12:06:46.790014	2025-10-30 12:10:59.277817
335	BARRE MARBREE	Autre	6.00	6.00	20.00	0.000	t	0.000	2025-10-30 12:06:46.790014	2025-10-30 12:10:59.277817
319	CHABLIS EMILE DURAND 75CL T 0 750 9 800 6	Autre	1.00	1.00	20.00	0.000	t	58.000	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
318	BERG MOEL MIL MONDESIR 75C T 0 750 2 890 6	Autre	1.00	1.00	20.00	0.000	t	31.000	2025-10-30 12:06:46.790014	2025-10-30 12:09:02.576379
336	NESCAFE DOLCE GUSTO LUNGO X30 7 810 1	Autre	1.00	1.00	20.00	0.000	t	23.000	2025-10-30 12:06:46.790014	2025-10-30 12:12:16.376798
323	OASIS POMME /CASSIS /FRAM 2L 2 237 6	Autre	1.00	1.00	20.00	0.000	t	13.000	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
324	OASI POMM /CASS /FRAM 50CL PET 1 017 12	Autre	1.00	1.00	20.00	0.000	t	12.000	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
325	COCACOLA CHERRY SLIM 33CL 0 617 24	Autre	1.00	1.00	20.00	0.000	t	14.000	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
326	7UP CHERRY BTE 33CL SLIM 0 540 24	Autre	1.00	1.00	20.00	0.000	t	12.000	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
329	KINDER COUNTRY 0 490 40	Autre	1.00	1.00	20.00	0.000	t	19.000	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
316	HT MEDOC CH ARCINS CB 75CL T 0 750 8 917 6	Autre	1.00	1.00	20.00	0.000	t	1118.000	2025-10-30 12:06:46.790014	2025-10-30 12:12:27.379196
331	M M'S PEANUT 45G SACHETS 0 566 36	Autre	1.00	1.00	20.00	0.000	t	20.000	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
332	M&M'S CRISPY 36G 0 562 24	Autre	1.00	1.00	20.00	0.000	t	13.000	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
334	TUBO KG 30 MAD NATURE INDIV. 13 160 1	Autre	1.00	1.00	20.00	0.000	t	13.000	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
337	YOP 50CL VANILLE 1 300 1	Autre	3.00	3.00	20.00	0.000	t	3.000	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
338	YOP 50CL FRAISE 1 300 1	Autre	3.00	3.00	20.00	0.000	t	3.000	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
339	YOP FRAISE	Autre	8.00	8.00	20.00	0.000	t	2.000	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
340	YOP FRAMBOISE	Autre	8.00	8.00	20.00	0.000	t	2.000	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
341	SKYR A BOIRE FRUIT ROUGE	Autre	2.00	2.00	20.00	0.000	t	7.000	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
315	WH GLENFIDDICH 15A 40D 70CL S 40 0 0 280 0 700 44 230 1	Autre	3.00	3.00	20.00	0.000	t	3542.000	2025-10-30 12:06:46.790014	2025-10-30 12:11:39.640331
320	LEFFE BLONDE 6.6 BLE 33CL B 6 6 0 022 0 330 0 847 12	Autre	3.00	3.00	20.00	0.000	t	110.000	2025-10-30 12:06:46.790014	2025-10-30 12:11:53.816872
327	OIGNON BLANC POUDRE SAC	Autre	5.00	5.00	20.00	0.000	t	0.000	2025-10-30 12:06:46.790014	2025-10-30 12:09:38.699924
317	BRG.CHARD V.VIGNOT 75CL T 0 750 5 310 6	Autre	2.00	2.00	20.00	0.000	t	133.000	2025-10-30 12:06:46.790014	2025-10-30 12:07:45.054577
310	FLEURS PLANTES 3 990 1	Autre	1.00	1.00	20.00	0.000	t	6.000	2025-10-30 12:06:22.270134	2025-10-30 12:08:00.448408
328	AIL EN POUDRE SAC	Autre	5.00	5.00	20.00	0.000	t	0.000	2025-10-30 12:06:46.790014	2025-10-30 12:09:38.699924
321	DESPERAD 5.9D 33CL VP // B 5 9 0 019 0 330 1 003 24	Autre	3.00	3.00	20.00	0.000	t	179.000	2025-10-30 12:06:46.790014	2025-10-30 12:11:53.816872
322	DESPERAD 5.9D 65CL VP B 5 9 0 038 0 650 2 452 12	Autre	1.00	1.00	20.00	0.000	t	59.000	2025-10-30 12:06:46.790014	2025-10-30 12:11:53.816872
330	MALTESERS SACHET 37G 0 631 25	Autre	1.00	1.00	20.00	0.000	t	30.000	2025-10-30 12:06:46.790014	2025-10-30 12:10:16.733895
342	SKYR A BOIRE VANILLE	Autre	2.00	2.00	20.00	0.000	t	7.000	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
343	CREME FRAI EP 15% 50CL ROCHAM 1 620 1	Autre	3.00	3.00	20.00	0.000	t	4.000	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
348	CAROTTES RONDELLES 2.5KG MC 4 530 1	Autre	1.00	1.00	20.00	0.000	t	4.000	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
349	TENDER CRUNCH PLT SPIC HAL 1KG 11 080 1	Autre	2.00	2.00	20.00	0.000	t	22.000	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
350	WING PLT TEXMEX 2 5KG HAL CERT 15 270 1	Autre	1.00	1.00	20.00	0.000	t	15.000	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
351	MPRO DIST SAVON MOUSSE	Hygiene	7.00	7.00	20.00	0.000	t	0.000	2025-10-30 12:06:46.790014	2025-10-30 12:06:46.790014
353	SCHROUMPF PIK TUBO X210 8 690 1	Autre	1.00	1.00	20.00	0.000	t	8.000	2025-10-30 12:07:11.398554	2025-10-30 12:07:11.398554
344	BRIOCHE TRANCHE	Autre	5.00	5.00	20.00	0.000	t	0.000	2025-10-30 12:06:46.790014	2025-10-30 12:10:59.277817
5	7UP Cherry 33 Cl	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
345	8 PAIN CHOCOLAT LC	Autre	3.00	3.00	20.00	0.000	t	30.000	2025-10-30 12:06:46.790014	2025-10-30 12:10:59.277817
346	10 PAIN LAIT LC	Autre	3.00	3.00	20.00	0.000	t	20.000	2025-10-30 12:06:46.790014	2025-10-30 12:10:59.277817
6	7UP Free Saveur Citron & Citron Vert 1,5 L	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
7	7UP Free Saveur Citron & Citron Vert 33 Cl	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
8	7UP Free Saveur Citron & Citron Vert 50 Cl	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
347	10 PAINS PEPITES LC	Autre	3.00	3.00	20.00	0.000	t	15.000	2025-10-30 12:06:46.790014	2025-10-30 12:10:59.277817
352	HEINEKEN 5D 65CL VP B 5 0 0 033 0 650 1 435 12 80	Autre	4.00	4.00	20.00	0.000	t	648.000	2025-10-30 12:07:11.398554	2025-10-30 12:12:16.376798
9	7UP Saveur Citron & Citron Vert 1,5 L	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
10	7UP Saveur Citron & Citron Vert 33 Cl	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
11	7UP Saveur Cocktail Exotique 33 Cl	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
12	7UP Saveur Mojito Citron Vert & Menthe 33 Cl	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
355	OEUF 30 M SOL ARO 0 227 30	Autre	4.00	4.00	20.00	0.000	t	27.000	2025-10-30 12:07:45.054577	2025-10-30 12:07:45.054577
13	ABSOLUT 700ML	Autre	0.00	22.90	20.00	0.000	t	2.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
367	PAYS OC CABERN SAUV 25CL MAZET T 0 250 1 470 12	Autre	1.00	1.00	20.00	0.000	t	68.000	2025-10-30 12:08:25.252336	2025-10-30 12:10:43.935296
359	EPINARD BRANCHE PALET 2.5KG MC 5 130 4	Autre	1.00	1.00	20.00	0.000	t	40.000	2025-10-30 12:07:45.054577	2025-10-30 12:12:27.379196
358	EPINARD BRANCHE PALET 2.5KG MC 5 140 1	Autre	2.00	2.00	20.00	0.000	t	10.000	2025-10-30 12:07:45.054577	2025-10-30 12:07:45.054577
395	SIRENE GISCOURS 18 MGX 75CL T 0 750 21 510 1	Autre	4.00	4.00	20.00	0.000	t	86.000	2025-10-30 12:09:02.576379	2025-10-30 12:09:02.576379
362	ARO FILM ALIMENTA	Autre	3.00	3.00	20.00	0.000	t	0.000	2025-10-30 12:08:00.448408	2025-10-30 12:08:00.448408
363	200 CHARLOTTE BLC 10 920 1	Autre	1.00	1.00	20.00	0.000	t	10.000	2025-10-30 12:08:00.448408	2025-10-30 12:08:00.448408
364	ARO ALU	Autre	2.00	2.00	20.00	0.000	t	0.000	2025-10-30 12:08:00.448408	2025-10-30 12:08:00.448408
360	MPRO ALU	Autre	3.00	3.00	20.00	0.000	t	0.000	2025-10-30 12:07:45.054577	2025-10-30 12:12:27.379196
396	SIRENE GISCOURS 18 MGX 75CL T 0 750 21 510 6	Autre	3.00	3.00	20.00	0.000	t	387.000	2025-10-30 12:09:02.576379	2025-10-30 12:09:02.576379
369	IGP MED RGE C. DAUPHINS 25CL T 0 250 1 350 12	Autre	1.00	1.00	20.00	0.000	t	94.000	2025-10-30 12:08:25.252336	2025-10-30 12:10:43.935296
365	VODKA POLIAKOV	Alcool	3.00	3.00	20.00	0.000	t	21.000	2025-10-30 12:08:25.252336	2025-10-30 12:11:53.816872
397	ROSE ANJOU MIL M.LAUR 75CL T 0 750 3 390 6	Autre	1.00	1.00	20.00	0.000	t	80.000	2025-10-30 12:09:02.576379	2025-10-30 12:10:43.935296
370	IGP MED RSE C.DAUPHINS 25CL T 0 250 1 350 12	Autre	2.00	2.00	20.00	0.000	t	93.000	2025-10-30 12:08:25.252336	2025-10-30 12:10:43.935296
379	SAN PELL 50CL PET 0 478 24	Autre	3.00	3.00	20.00	0.000	t	53.000	2025-10-30 12:08:25.252336	2025-10-30 12:11:53.816872
378	COCA-COLA PET 50CLX24 PROMO 0 922 24	Autre	1.00	1.00	20.00	0.000	t	22.000	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
380	PERRIER 6*50CL PET 0 565 24	Autre	1.00	1.00	20.00	0.000	t	13.000	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
398	ATLANTIQ IGP OCEADE BLC 75CL T 0 750 1 830 6	Autre	1.00	1.00	20.00	0.000	t	10.000	2025-10-30 12:09:02.576379	2025-10-30 12:09:02.576379
399	CH V. CLICQUOT BRUT 75CL M 0 750 37 715 6	Autre	1.00	1.00	20.00	0.000	t	668.000	2025-10-30 12:09:02.576379	2025-10-30 12:12:16.376798
384	ALLUMETTE FUM BOIS HETR 1KG MC 6 460 1	Autre	1.00	1.00	20.00	0.000	t	6.000	2025-10-30 12:08:25.252336	2025-10-30 12:08:25.252336
354	LEFFE BLONDE 75CL 6.6D VP B 6 6 0 050 0 750 2 505 6	Autre	4.00	4.00	20.00	0.000	t	195.000	2025-10-30 12:07:45.054577	2025-10-30 12:12:16.376798
372	1	Autre	664.00	664.00	20.00	0.000	t	20.000	2025-10-30 12:08:25.252336	2025-10-30 12:12:16.376798
387	IGP MED BLC C. DAUPHINS 25CL T 0 250 1 350 12	Autre	1.00	1.00	20.00	0.000	t	16.000	2025-10-30 12:08:39.842775	2025-10-30 12:08:39.842775
388	MX MUSCADOR ROSE 75CL M 0 750 2 220 6	Autre	1.00	1.00	20.00	0.000	t	13.000	2025-10-30 12:08:39.842775	2025-10-30 12:08:39.842775
373	RIOBA ABC ORANGE TO 25CL 0 722 24	Autre	1.00	1.00	20.00	0.000	t	34.000	2025-10-30 12:08:25.252336	2025-10-30 12:10:16.733895
390	ARO SEL FIN BV	Autre	7.00	7.00	20.00	0.000	t	5.000	2025-10-30 12:08:39.842775	2025-10-30 12:08:39.842775
371	CH V.PELLETIER BRT 75CL M 0 750 13 275 6	Autre	1.00	1.00	20.00	0.000	t	317.000	2025-10-30 12:08:25.252336	2025-10-30 12:09:02.576379
392	LAY'S BARBECUE	Autre	1.00	1.00	20.00	0.000	t	4.000	2025-10-30 12:08:39.842775	2025-10-30 12:08:39.842775
393	LAY'S BARBECUE SACHET 45G 0 590 20	Autre	1.00	1.00	20.00	0.000	t	11.000	2025-10-30 12:08:39.842775	2025-10-30 12:08:39.842775
374	RIOBA ABC ANANAS TO 25CL 0 795 24	Autre	1.00	1.00	20.00	0.000	t	36.000	2025-10-30 12:08:25.252336	2025-10-30 12:10:16.733895
366	COGN MEUKOV BLACK VS 40D 70CL S 40 0 0 280 0 700 21 020 1	Autre	2.00	2.00	20.00	0.000	t	131.000	2025-10-30 12:08:25.252336	2025-10-30 12:09:38.699924
385	ARO LIQ VAISS MAIN CIT 10L 1 046 10	Autre	1.00	1.00	20.00	0.000	t	20.000	2025-10-30 12:08:25.252336	2025-10-30 12:10:59.277817
368	BDX RGE CH LES VERGNES 75CL T 0 750 3 325 6	Autre	2.00	2.00	20.00	0.000	t	133.000	2025-10-30 12:08:25.252336	2025-10-30 12:09:38.699924
375	RIOBA PUR JUS RAISIN TO 25CL 0 646 12	Boissons	1.00	1.00	20.00	0.000	t	14.000	2025-10-30 12:08:25.252336	2025-10-30 12:10:16.733895
386	BRG.ALIG V.VIGNOT 75CL T 0 750 5 500 6	Autre	1.00	1.00	20.00	0.000	t	66.000	2025-10-30 12:08:39.842775	2025-10-30 12:09:38.699924
391	MC MOUTARDE DIJON 5KG 1 898 5	Autre	1.00	1.00	20.00	0.000	t	27.000	2025-10-30 12:08:39.842775	2025-10-30 12:12:16.376798
389	VINAIGRE BLANC 8° - 1L ARO 0 490 12	Alcool	1.00	1.00	20.00	0.000	t	10.000	2025-10-30 12:08:39.842775	2025-10-30 12:09:38.699924
376	RIOBA NECTAR BANANE TO 25CL 0 673 12	Autre	1.00	1.00	20.00	0.000	t	16.000	2025-10-30 12:08:25.252336	2025-10-30 12:10:16.733895
361	ARO LIQ VAISS MAIN CIT 20L 24 990 1	Autre	1.00	1.00	20.00	0.000	t	124.000	2025-10-30 12:07:45.054577	2025-10-30 12:12:16.376798
381	ARO MAYO ALLEGEE ARO SEAU 5L 10 260 1	Boissons	1.00	1.00	20.00	0.000	t	40.000	2025-10-30 12:08:25.252336	2025-10-30 12:12:27.379196
377	RIOBA NECTAR ABRICOT TO 25CL 0 643 24	Autre	1.00	1.00	20.00	0.000	t	30.000	2025-10-30 12:08:25.252336	2025-10-30 12:10:16.733895
382	RIOBA MAYO BUCH	Autre	1.00	1.00	20.00	0.000	t	16.000	2025-10-30 12:08:25.252336	2025-10-30 12:10:16.733895
400	WH JWALKER BLACK 12A 40D 70CL S 40 0 0 280 0 700 17 190 6	Autre	1.00	1.00	20.00	0.000	t	103.000	2025-10-30 12:09:38.699924	2025-10-30 12:09:38.699924
401	PAIN HOT DOG BRIOCHE 6X45G MC 2 020 1	Autre	1.00	1.00	20.00	0.000	t	2.000	2025-10-30 12:09:38.699924	2025-10-30 12:09:38.699924
402	WHISKY CHIVAS 18ANS 40D 70CL S 40 0 0 280 0 700 42 530 1	Alcool	2.00	2.00	20.00	0.000	t	85.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
403	VDK WYBOROWA	Autre	3.00	3.00	20.00	0.000	t	7.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
404	VODKA SMIRNOFF	Alcool	3.00	3.00	20.00	0.000	t	7.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
405	VDK ERISTOFF	Autre	3.00	3.00	20.00	0.000	t	7.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
406	VODKA ABSOLUT BLUE 40D 70CL S 40 0 0 280 0 700 11 020 1	Alcool	2.00	2.00	20.00	0.000	t	22.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
407	VODKA BELVEDERE BIO* 40D 20CL S 40 0 0 080 0 200 9 590 1	Alcool	8.00	8.00	20.00	0.000	t	76.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
408	RHUM STJAMES PAILLE 40D 70CL G 40 0 0 280 0 700 10 580 1	Alcool	1.00	1.00	20.00	0.000	t	10.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
411	CTE BLAYE HT LA POINTE RG 75CL T 0 750 4 250 6	Autre	1.00	1.00	20.00	0.000	t	25.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
412	MEDOC PUY VALLON RGE 75CL T 0 750 2 990 6	Autre	2.00	2.00	20.00	0.000	t	35.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
413	IGP MED RSE CLAIR ESTEL 75CL T 0 750 3 390 6	Autre	1.00	1.00	20.00	0.000	t	20.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
414	PAYSOC CINS RSEMIL DELLAC75CL T 0 750 1 990 6	Autre	1.00	1.00	20.00	0.000	t	11.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
415	CHARDONNAY IGP LOIR 75CL T 0 750 3 590 6	Autre	1.00	1.00	20.00	0.000	t	21.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
416	RIOBA BOISS TROPICAL TO25CL 0 581 12	Autre	1.00	1.00	20.00	0.000	t	6.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
417	RIOBA BOISS POM KIWI TO 25CL 0 690 12	Autre	1.00	1.00	20.00	0.000	t	8.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
419	MC MAYO HTE FERMETE 4 7KG 12 850 1	Autre	1.00	1.00	20.00	0.000	t	12.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
420	KINDER BUENO WHITE 0 714 30	Autre	3.00	3.00	20.00	0.000	t	64.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
421	FREEDENT WHITE MENTHVERT10D 0 523 30	Autre	1.00	1.00	20.00	0.000	t	15.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
422	CHEW.GUM FRAISE BOIS DRG 0 665 20	Autre	1.00	1.00	20.00	0.000	t	13.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
423	FREEDENT MENTHE VERTE 10DR 0 494 30	Autre	1.00	1.00	20.00	0.000	t	14.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
424	HWD 10 DR S/S GREENFRESH 0 602 20	Autre	1.00	1.00	20.00	0.000	t	12.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
425	HWD STYLE CHLORO 12 GUMS B 0 611 18	Autre	1.00	1.00	20.00	0.000	t	11.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
426	HWD STYLE COCKTAIL 12 GUM 0 602 18	Autre	1.00	1.00	20.00	0.000	t	10.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
427	UNICORN DIPPER 1 218 12	Autre	1.00	1.00	20.00	0.000	t	14.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
356	PAIN MIE NATURE LC	Autre	5.00	5.00	20.00	0.000	t	15.000	2025-10-30 12:07:45.054577	2025-10-30 12:10:16.733895
357	P. MIE COMPLET LC	Autre	5.00	5.00	20.00	0.000	t	10.000	2025-10-30 12:07:45.054577	2025-10-30 12:10:16.733895
428	BRIOCH BAGEL 4X75G LFD 2 470 1	Autre	2.00	2.00	20.00	0.000	t	4.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
429	PAIN HOT DOG BRIOCHE 4X85G MC 2 350 1	Autre	2.00	2.00	20.00	0.000	t	4.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
430	JB CUIT TORCHON SUPDD 10TRX90G 8 950 1	Autre	1.00	1.00	20.00	0.000	t	8.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
431	SPICY PLT PANE 1KG S_AT HALAL 9 570 1	Autre	1.00	1.00	20.00	0.000	t	9.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
432	MILANESE VOLAILLE 8X	Autre	1.00	1.00	20.00	0.000	t	2.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
418	MAUREL HLE TOURNESOL 25L 1 780 25	Autre	1.00	1.00	20.00	0.000	t	93.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:59.277817
383	30 MADELEINES CHOCO TUBO 1KG 14 320 1	Autre	1.00	1.00	20.00	0.000	t	56.000	2025-10-30 12:08:25.252336	2025-10-30 12:10:59.277817
409	RHUM LM.BLC 40D 20CL X6 G 40 0 0 080 0 200 2 498 6	Alcool	2.00	2.00	20.00	0.000	t	43.000	2025-10-30 12:10:16.733895	2025-10-30 12:11:53.816872
410	RHUM AMBRE LM 40D 20CL X6 G 40 0 0 080 0 200 2 498 6	Alcool	2.00	2.00	20.00	0.000	t	43.000	2025-10-30 12:10:16.733895	2025-10-30 12:11:53.816872
433	CORDON DE VOLAILLE 1KG HALAL 6 520 1	Autre	1.00	1.00	20.00	0.000	t	6.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
434	DONUTS POULET 8X	Autre	1.00	1.00	20.00	0.000	t	0.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
435	SCISSE FRANCF X20 BN 1.1KG ENV 1 266 11 340	Autre	1.00	1.00	20.00	0.000	t	14.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
394	EPINARDS HACHES 2.5KG MC 4 323 4	Autre	1.00	1.00	20.00	0.000	t	34.000	2025-10-30 12:08:39.842775	2025-10-30 12:10:16.733895
436	CRISPERS 2.5KG MCCAIN 8 370 1	Autre	1.00	1.00	20.00	0.000	t	8.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
437	WINGS PLT CRUNCH SPICY 1KG HAL 7 320 1	Autre	1.00	1.00	20.00	0.000	t	7.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
438	ARO LIQ VAISS MAIN CIT 5L 6 670 1	Autre	1.00	1.00	20.00	0.000	t	6.000	2025-10-30 12:10:16.733895	2025-10-30 12:10:16.733895
441	ROCHE MAZET MERLOT 75CL IGP T 0 750 2 330 6	Autre	1.00	1.00	20.00	0.000	t	13.000	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
442	CH FEUILLATE TRADITION BRT 75C M 0 750 18 800 6	Autre	1.00	1.00	20.00	0.000	t	112.000	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
443	OASIS TROPICAL 50CL PET 1 034 12	Autre	1.00	1.00	20.00	0.000	t	12.000	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
444	SCHWEPPES IT PET 4X50CL 0 828 24	Autre	1.00	1.00	20.00	0.000	t	19.000	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
445	PERRIER 1L PET 0 637 6	Autre	2.00	2.00	20.00	0.000	t	7.000	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
446	BUCHETTE 4G C3 KG BS 10 010 1	Autre	1.00	1.00	20.00	0.000	t	10.000	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
447	PRINGLES BBQ	Autre	1.00	1.00	20.00	0.000	t	7.000	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
448	PRINGLES ORIGINAL	Alcool	1.00	1.00	20.00	0.000	t	7.000	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
449	PRINGLES PAPRIKA	Autre	1.00	1.00	20.00	0.000	t	7.000	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
14	ANJU MOONG 1KG	Autre	0.00	5.90	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
450	PRINGLES CREAM OIGNON	Autre	1.00	1.00	20.00	0.000	t	7.000	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
451	KINDER BUENO WHITE 0 630 30	Autre	1.00	1.00	20.00	0.000	t	18.000	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
15	ANJU URID 1KG	Autre	0.00	5.80	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
452	SIGMA 15 RL 60X46X12 THER SBPA 18 180 1	Autre	1.00	1.00	20.00	0.000	t	18.000	2025-10-30 12:10:43.935296	2025-10-30 12:10:43.935296
453	WH JACK DANIEL'S 40D 35CL S 40 0 0 140 0 350 10 130 1	Autre	3.00	3.00	20.00	0.000	t	30.000	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
454	WHISKY CHIVAS 12A 40D 70CL S 40 0 0 280 0 700 20 860 6	Alcool	1.00	1.00	20.00	0.000	t	125.000	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
440	WH JWALKER BLACK 12A 40D 70CL S 40 0 0 280 0 700 20 628 6	Autre	1.00	1.00	20.00	0.000	t	226.000	2025-10-30 12:10:43.935296	2025-10-30 12:10:59.277817
456	WH GRANTS TRIPLE WOOD 40D 20CL S 40 0 0 080 0 200 3 623 6	Autre	1.00	1.00	20.00	0.000	t	21.000	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
457	WH JACK DANIEL'S 40D 20CL S 40 0 0 080 0 200 6 630 8	Autre	1.00	1.00	20.00	0.000	t	53.000	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
16	ANNAM DIAMOND 1KG	Autre	0.00	3.90	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
458	VODKA ABSOLUT 40D 35CL S 40 0 0 140 0 350 7 850 1	Alcool	3.00	3.00	20.00	0.000	t	23.000	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
459	BAILEYS IRISH CREME 17D 70CL S 17 0 0 119 0 700 11 150 6	Autre	4.00	4.00	20.00	0.000	t	267.000	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
460	MARTINI ROSATO	Autre	1.00	1.00	20.00	0.000	t	4.000	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
461	MARTINI BLC	Autre	1.00	1.00	20.00	0.000	t	4.000	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
462	MARTINI RGE	Autre	1.00	1.00	20.00	0.000	t	4.000	2025-10-30 12:10:59.277817	2025-10-30 12:10:59.277817
17	ANNY SARDINE OIL	Autre	0.00	1.30	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
455	WHISKY CHIVAS 18ANS 40D 70CL S 40 0 0 280 0 700 37 530 3	Alcool	2.00	2.00	20.00	0.000	t	592.000	2025-10-30 12:10:59.277817	2025-10-30 12:11:39.640331
439	WH JACK DANIEL'S 40D 70CL S 40 0 0 280 0 700 16 180 1	Autre	6.00	6.00	20.00	0.000	t	194.000	2025-10-30 12:10:43.935296	2025-10-30 12:11:53.816872
18	ANTIE BOUILLON POULE 1KG	Autre	0.00	5.50	20.00	0.000	t	3.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
463	WHISKY CHIVAS 12A 40D 70CL S 40 0 0 280 0 700 23 640 1	Alcool	1.00	1.00	20.00	0.000	t	23.000	2025-10-30 12:11:25.7753	2025-10-30 12:11:25.7753
464	BS TI MANGUE PASSION 32D 70CL S 32 0 0 224 0 700 20 030 1	Autre	1.00	1.00	20.00	0.000	t	20.000	2025-10-30 12:11:25.7753	2025-10-30 12:11:25.7753
465	BAILEYS IRISH CREME 17D 70CL S 17 0 0 119 0 700 11 150 1	Autre	2.00	2.00	20.00	0.000	t	22.000	2025-10-30 12:11:25.7753	2025-10-30 12:11:25.7753
466	HEINEKEN PACK 5D 20X25CL VP B 5 0 0 013 0 250 0 589 20	Autre	2.00	2.00	20.00	0.000	t	23.000	2025-10-30 12:11:25.7753	2025-10-30 12:11:25.7753
467	CACAHUETES GRILLEES SALEES 1KG 4 460 1	Autre	1.00	1.00	20.00	0.000	t	4.000	2025-10-30 12:11:25.7753	2025-10-30 12:11:25.7753
468	0	Autre	9.00	9.00	20.00	0.000	t	4.000	2025-10-30 12:11:25.7753	2025-10-30 12:11:25.7753
469	WH GLENMORANGIE 18A 43D 70CL S 43 0 0 301 0 700 69 280 1	Autre	1.00	1.00	20.00	0.000	t	69.000	2025-10-30 12:11:39.640331	2025-10-30 12:11:39.640331
470	WHISKY CARDHU 12A 40D 70CL S 40 0 0 280 0 700 32 270 1	Alcool	2.00	2.00	20.00	0.000	t	64.000	2025-10-30 12:11:39.640331	2025-10-30 12:11:39.640331
471	WHISKY DALMORE 12A 40D 70CL S 40 0 0 280 0 700 51 650 1	Alcool	2.00	2.00	20.00	0.000	t	103.000	2025-10-30 12:11:39.640331	2025-10-30 12:11:39.640331
472	WH TOGOUCHI PREMIUM 40D 70CL S 40 0 0 280 0 700 34 570 1	Autre	1.00	1.00	20.00	0.000	t	34.000	2025-10-30 12:11:39.640331	2025-10-30 12:11:39.640331
473	WH MACALLAN 12A DBCSK 40D 70CL S 40 0 0 280 0 700 74 700 1	Autre	2.00	2.00	20.00	0.000	t	149.000	2025-10-30 12:11:39.640331	2025-10-30 12:11:39.640331
474	WH GLENFIDDICH SB 18A 40D 70CL S 40 0 0 280 0 700 70 070 1	Autre	3.00	3.00	20.00	0.000	t	210.000	2025-10-30 12:11:39.640331	2025-10-30 12:11:39.640331
475	WH MONKEY SHOULDER 40D 70CL S 40 0 0 280 0 700 19 175 6	Autre	1.00	1.00	20.00	0.000	t	115.000	2025-10-30 12:11:39.640331	2025-10-30 12:11:39.640331
476	RIGATONI NAPOL.CECCO	Autre	5.00	5.00	20.00	0.000	t	0.000	2025-10-30 12:11:39.640331	2025-10-30 12:11:39.640331
477	MPRO BOBINE 2P	Autre	4.00	4.00	20.00	0.000	t	5.000	2025-10-30 12:11:39.640331	2025-10-30 12:11:39.640331
478	HEINEKEN TACT 5D 4X50CL CAN B 5 0 0 025 0 500 0 870 24	Autre	1.00	1.00	20.00	0.000	t	20.000	2025-10-30 12:11:53.816872	2025-10-30 12:11:53.816872
479	RED BULL BOITE 25CL 1 020 24	Autre	3.00	3.00	20.00	0.000	t	73.000	2025-10-30 12:11:53.816872	2025-10-30 12:11:53.816872
480	MONSTER ENERGY BOITE 50CL 1 075 24	Autre	2.00	2.00	20.00	0.000	t	51.000	2025-10-30 12:11:53.816872	2025-10-30 12:11:53.816872
481	COCA COLA PET 50CL 1 025 24	Autre	2.00	2.00	20.00	0.000	t	49.000	2025-10-30 12:11:53.816872	2025-10-30 12:11:53.816872
482	L'OR ESPRESSO SPLENDENTE 50 CA 13 850 1	Autre	1.00	1.00	20.00	0.000	t	13.000	2025-10-30 12:11:53.816872	2025-10-30 12:11:53.816872
19	ARO PULPE TOMATE 400f	Autre	0.00	1.00	5.50	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
20	ARO VINAIGRE B 1L	Alcool	0.00	1.50	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
21	BACARDI CARTA BLANCA 70CL	Autre	0.00	24.90	20.00	0.000	t	2.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
22	BACARDI CARTA ORO 70CL	Autre	0.00	20.39	20.00	0.000	t	2.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
23	BALLANTINE 35CL	Autre	0.00	15.99	20.00	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
24	BARRE MARBRE CAC BF	Autre	0.00	3.50	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
25	BARRE MARBREE 600G	Autre	0.00	3.50	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
26	BARRE PATISSIERE 600G	Autre	0.00	3.80	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
27	BELLE ANTI CALCAIRE	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
28	BELLE B.MAÏS MIEL	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
29	BELLE BLÉ S.MIEL	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
30	BELLE BÂT.CH.LAIT	Autre	0.00	2.20	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
31	BELLE DÉG.ORANGE	Autre	0.00	1.49	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
32	BELLE DÉG.ULTRA	Autre	0.00	1.49	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
33	BELLE DÉGR.FRAMB	Autre	0.00	1.49	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
34	BELLE F - CANNELLONI 400G	Autre	0.00	2.50	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
35	BELLE F - CASSOULET 800G	Autre	0.00	4.50	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
36	BELLE F - EPINARD HACHE 790G	Autre	0.00	2.70	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
37	BELLE F - FILET SARDINE CITRON 100G	Autre	0.00	1.90	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
38	BELLE F - GAUFRETTES CACAO 175G	Autre	0.00	1.80	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
39	BELLE F - PETIT BEURRE CH B150G	Autre	0.00	1.90	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
40	BELLE F - PETIT POIS 800G	Autre	0.00	3.90	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
41	BELLE F - POIS CHICHES 800G	Autre	0.00	2.50	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
42	BELLE F - RAVIOLI BOLOGN. 800G	Autre	0.00	7.50	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
43	BELLE F - VINAIGRE XERES 50CL	Alcool	0.00	2.99	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
44	BELLE F BOEUF BOURG 400g	Autre	0.00	3.00	5.50	0.000	t	10.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
45	BELLE F CASSOULET 420G	Autre	0.00	1.70	20.00	0.000	t	5.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
46	BELLE F CHOUCROUTE GARNIE 400g	Autre	0.00	2.50	20.00	0.000	t	9.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
47	BELLE F MAIS DOUX 300G	Autre	0.00	1.90	20.00	0.000	t	7.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
48	BELLE F POIS CHICHES 400G	Autre	0.00	1.99	20.00	0.000	t	18.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
49	BELLE F SARDINES FLT TOMATE 100G	Autre	0.00	1.99	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
50	BELLE F SAUCE BOLOG 200G	Autre	0.00	1.90	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
51	BELLE F SAUCISSES LENT 420g	Autre	0.00	2.50	20.00	0.000	t	8.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
52	BELLE F. JEUNES CAROTTES	Autre	0.00	1.50	20.00	0.000	t	4.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
53	BELLE FR.AD.LAV.14	Autre	0.00	3.60	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
54	BELLE FR.SIROP FR.	Autre	0.00	0.00	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
55	BELLE FTHON ALBACORE 112G	Autre	0.00	3.30	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
56	BELLE GEL D.L.C	Autre	0.00	2.20	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
57	BELLE GEL WC MARINE	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
58	BELLE GEL WC PIN	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
59	BELLE MOUCH.ALOÉ V	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
60	BELLE MÈCHE FL.BL.	Autre	0.00	2.99	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
61	BELLE MÈCHE LAV.	Autre	0.00	2.99	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
62	BELLE NET.MARINE	Autre	0.00	2.30	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
63	BELLE NET.MULTI SUR	Autre	0.00	2.30	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
64	BELLE PÉCIAL SAN.N.	Autre	0.00	1.90	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
65	BELLE SER.ULTRA	Autre	0.00	1.90	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
66	BELLE SER.ULTRA N	Autre	0.00	1.90	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
67	BELLE SHAMP.US.FRÉQ	Autre	0.00	2.49	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
68	BELVEDERE 20CL	Autre	0.00	17.90	20.00	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
69	BENS RIZ LONG GRAIN	Autre	0.00	3.50	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
70	BLACK LABEL 70CL	Autre	0.00	30.90	20.00	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
71	Belle F Epinards Branche 380g	Autre	0.00	2.70	20.00	0.000	t	8.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
72	Belle Haricots rouges 400g	Autre	0.00	1.80	5.50	0.000	t	26.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
73	Bonduelle mais 300g	Autre	0.00	2.50	20.00	0.000	t	7.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
74	Bouillon De Poulet	Autre	0.00	1.99	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
75	Bouillon de crevette	Autre	0.00	1.99	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
76	Bouillon de poisson	Autre	0.00	1.99	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
77	CARIBBEAN SAISON RUM 70CL	Autre	0.00	1.00	20.00	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
78	CELLIER .D 75CL	Autre	0.00	7.50	20.00	0.000	t	6.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
79	CERELAC 400 G	Autre	0.00	6.50	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
80	CHABLIS 75CL	Autre	0.00	18.90	20.00	0.000	t	3.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
81	CHAMPIGNONS 400G	Autre	0.00	2.39	20.00	0.000	t	7.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
82	CHARDONNAY GILBERT CHON 70CL	Autre	0.00	9.70	20.00	0.000	t	11.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
83	CHAT CHAMP DE MARS 2020 75CL	Autre	0.00	6.99	20.00	0.000	t	2.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
84	CHAT D'ARCINS 2019 75CL	Autre	0.00	19.90	20.00	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
85	CHAT HAUT POINT 75CL	Autre	0.00	9.90	20.00	0.000	t	6.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
86	CHAT.CAMPAR.75CL	Autre	0.00	12.99	20.00	0.000	t	4.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
87	CHIVAS 12 70CL	Autre	0.00	29.90	20.00	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
88	CHT CLEMENT PICHON 2016 70CL	Autre	0.00	16.50	20.00	0.000	t	2.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
89	CIROC APPLE 70CL	Autre	0.00	49.99	20.00	0.000	t	2.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
90	CIROC BLEU CLASSIQUE 70CL	Autre	0.00	49.99	20.00	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
91	CIROC RED B 70CL	Autre	0.00	49.99	20.00	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
92	CLAN CAMPBELLN 35CL	Autre	0.00	10.90	20.00	0.000	t	2.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
93	CORNED  DOLO 340G	Autre	0.00	4.90	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
94	COTES DU RHONE 2022 1L	Autre	0.00	13.90	20.00	0.000	t	2.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
95	Coca Cola Cherry Coke 24x 330ml	Autre	0.00	2.19	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
96	Coca Cola Light	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
97	Coca Cola Zero	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
99	Coca-Cola Cherry	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
100	Coca-Cola Cherry — canette 33 cl	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
101	Coca-Cola Citron — canette 33 cl	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
102	Coca-Cola Goût Original Boîte 15CL x 8 MINI FRIGO PACK	Alcool	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
103	Coca-Cola Goût Original Boîte 33CL	Alcool	0.00	0.76	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
98	Coca-Cola Can Multipack, 24 X 330 Ml	Alcool	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
104	Coca-Cola Goût Original IVC 33CL	Alcool	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
105	Coca-Cola Goût Original IVP 25CL	Alcool	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
106	Coca-Cola Goût Original IVP 750ML	Alcool	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
107	Coca-Cola Goût Original LVC 1L	Alcool	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
108	Coca-Cola Goût Original PET 1,25L	Alcool	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
109	Coca-Cola Goût Original PET 1,25L x 12	Alcool	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
110	Coca-Cola Goût Original PET 1,25L x 6	Alcool	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
111	Coca-Cola Goût Original PET 1L	Alcool	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
112	Coca-Cola Goût Original PET 50CL	Alcool	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
113	Coca-Cola Goût Original — canette 33 cl	Alcool	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
114	Coca-Cola Goût Original — canette 33 cl (DK)	Alcool	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
115	Coca-Cola Goût Original — canette 33 cl (UK)	Alcool	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
116	Coca-Cola Light	Autre	0.00	1.50	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
117	Coca-Cola Light Citron — canette 33 cl	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
118	Coca-Cola Light Sans Caféine — canette 33 cl	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
119	Coca-Cola Light Taste	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
120	Coca-Cola Light — canette 33 cl	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
121	Coca-Cola Zero Citron Vert — canette 33 cl	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
122	Coca-Cola Zero Sucre Y3000 — canette 33 cl (édition)	Autre	0.00	0.00	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
123	Coca-Cola Zero Sucre — canette 33 cl	Autre	0.00	0.00	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
124	Coca-Cola Zero Sucre — canette 33 cl (DK)	Autre	0.00	0.00	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
125	Coca-Cola Zero Sucre — canette 33 cl (pack ref.)	Autre	0.00	0.00	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
126	Compari bitter 1L	Autre	0.00	21.10	20.00	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
127	Crème Carbonara	Autre	0.00	3.50	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
128	DADDY SUCRE CANNE 750G	Autre	0.00	3.30	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
129	DIDON SUCRE MORC.	Autre	0.00	3.50	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
130	Dentifrice Haleine Pure 75ml	Autre	0.00	3.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
131	ERISTOFF 70CL	Autre	0.00	19.50	20.00	0.000	t	2.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
132	EXETER CHICKEN 340G	Autre	0.00	2.99	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
133	EXETER CORNED BEEF 198G	Autre	0.00	3.90	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
134	EXETER CORNED BEEF 340G	Autre	0.00	5.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
135	FARINE DE BLE 1KG	Autre	0.00	1.90	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
136	FARINE TYPE 55	Autre	0.00	1.90	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
137	Fanta Citron Zéro Sucre — canette 33 cl (UK)	Autre	0.00	0.00	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
138	Fanta Citron — canette 33 cl	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
139	Fanta Citron — canette 33 cl (DK)	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
140	Fanta Citron — canette 33 cl (ES)	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
141	Fanta Citron — canette 33 cl (slim)	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
142	Fanta Exotic — canette 33 cl (DK)	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
143	Fanta Exotic — canette 33 cl (UK)	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
144	Fanta Fraise & Kiwi — canette 33 cl (DK)	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
145	Fanta Fraise & Kiwi — canette 33 cl (UK)	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
146	Fanta Lemon & Elderflower (Shokata) — canette 33 cl (UK)	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
147	Fanta Mangue & Fruit du Dragon — canette 33 cl (UK)	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
148	Fanta Orange — canette 33 cl	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
149	Fanta Orange — canette 33 cl (ES)	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
150	Fanta Orange — canette 33 cl (UK)	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
151	Fanta Sandía (Pastèque) — canette 33 cl (ES)	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
152	Fanta Shokata — canette 33 cl (ES)	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
153	Fish Sauce	Autre	0.00	3.40	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
154	GHANA FRESH 400G	Autre	0.00	3.99	20.00	0.000	t	17.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
155	GIBSON'S GIN 70CL	Alcool	0.00	17.90	20.00	0.000	t	2.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
156	GRANOLA 200G	Autre	0.00	2.90	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
157	GRANT'S WHISKY 70CL	Alcool	0.00	26.90	20.00	0.000	t	3.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
158	GUILLOTINE VODKA 70CL	Alcool	0.00	49.99	20.00	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
159	HAPPI LIFE GINGER DRINK 0.5L	Alcool	0.00	3.90	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
160	HAPPY DAYS 180G	Autre	0.00	1.90	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
161	HAUT CHAMBOUSTIN MERLOT 2021	Autre	0.00	11.90	20.00	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
162	HENNESSY 70CL	Autre	0.00	58.90	20.00	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
163	HUILE DE PALME MAMA FUTA	Autre	0.00	1.00	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
164	Ice Tea - Saveur Framboise	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
165	Ice Tea Saveurs Pastèque Et Menthe	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
166	JACK DANIEL 200ML	Autre	0.00	11.90	20.00	0.000	t	2.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
167	JACK DANIEL'S 70CL	Autre	0.00	27.90	20.00	0.000	t	3.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
168	JACK DANIEL'S APPLE 70CL	Autre	0.00	29.99	20.00	0.000	t	2.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
169	JACK DANIEL'S FIRE 35CL	Autre	0.00	17.90	20.00	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
170	JACK DANIEL'S HONEY 70CL	Autre	0.00	28.90	20.00	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
171	JACK MACKEREL 425G	Autre	0.00	4.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
172	JB WHISKY 35CL	Alcool	0.00	13.90	20.00	0.000	t	3.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
173	JB WHISKY 70CL	Alcool	0.00	18.90	20.00	0.000	t	4.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
174	JC PREMIUM Pollen Filter B40017PR Pollen Filter 240 204 35 VAUXHALL: Astra Mk6, Insignia Mk1, ZAFIRA Mk3, OPEL: Astra J Hatchback	Autre	0.00	3.98	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
175	JEAN DEGAVES 2013 75CL	Autre	0.00	6.99	20.00	0.000	t	3.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
176	JEAN DELLAC CINSAULT	Autre	0.00	6.90	20.00	0.000	t	6.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
177	JP CHENET C-S 75CL	Autre	0.00	7.50	20.00	0.000	t	5.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
178	L OCEADE MERLOT 75CL	Autre	0.00	7.90	20.00	0.000	t	5.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
179	LA BRIOCHE TR 500G	Autre	0.00	3.50	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
180	LA FLEUR MONDESIR 2024	Autre	0.00	7.90	20.00	0.000	t	6.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
181	LA ROSINA 400G	Autre	0.00	2.20	20.00	0.000	t	10.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
182	LABEL 5 35CL	Autre	0.00	1.00	20.00	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
183	LABEL 5 70CL	Autre	0.00	19.90	20.00	0.000	t	3.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
184	LAFAURIE M. CASTILLON 2016	Autre	0.00	10.90	20.00	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
185	LE PETIT BEURRE 145	Autre	0.00	1.90	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
186	LOTUS RIZ LONG10KG	Autre	0.00	27.90	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
187	LOUIS MARTIN - TOMATES ENTIERES 765G	Autre	0.00	1.00	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
188	La fleur de mondésir sémillon	Autre	0.00	9.90	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
189	Lipt Peche Zero Bib 10l (72x1)	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
190	Lipton Ice Tea Pastèque Menthe	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
191	Lipton Ice Tea Saveur Citron Citron Vert	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
192	Lipton Ice Tea Saveur Citron Citron Vert 1,25 L	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
193	Lipton Ice Tea Saveur Pêche	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
194	Lipton Ice Tea Saveur Pêche 1,25 L	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
195	Lipton Ice Tea Saveur Pêche 1,75 L	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
196	Lipton Ice Tea Saveur Pêche 25 Cl	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
197	Lipton Ice Tea Saveur Pêche Sans Sucres	Autre	0.00	1.00	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
198	Lipton Liptonic L'original Pétillant 1,5 L	Alcool	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
199	Lipton Thé Vert Glacé Saveur Citron Vert Menthe 33 Cl	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
200	Liptonic	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
201	MACEDOINE 265G	Autre	0.00	1.50	20.00	0.000	t	10.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
202	MAGGI AROME 960G	Autre	0.00	5.90	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
203	MAIN GOURD - EPINARD HACHES 800G	Autre	0.00	3.30	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
204	MAMA AFRICA - HUILE PALME ROUGE	Autre	0.00	3.50	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
205	MARQUIS DES BOIS 2020 75CL	Autre	0.00	1.00	20.00	0.000	t	3.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
206	MILKA CHOCO MOO	Autre	0.00	3.50	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
207	MILKA CHOCO WHITE	Autre	0.00	3.50	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
208	MOUTARDE FINE 280G	Autre	0.00	2.50	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
209	Mirinda Boisson Gazeuse Goût Ananas 2 L	Boissons	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
210	Mirinda Boisson Gazeuse Goût Fraise 2 L	Boissons	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
211	Mirinda Boisson Gazeuse Goût Orange 2 L	Boissons	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
212	Mirinda Boisson Gazeuse Goût Pomme Kiwi 2 L	Boissons	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
213	Mirinda Orange 33cl (Pack De 24)	Autre	0.00	19.99	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
214	Mirinda Strawberry 330ml X 24	Autre	0.00	19.40	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
215	Monster Ultra Fiesta Mango	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
216	Muscador blanc	Autre	0.00	4.90	20.00	0.000	t	2.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
217	Muscador rose	Autre	0.00	4.90	20.00	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
218	NUMBER ONE BOUILLON BOEUF 1KG	Autre	0.00	5.50	5.50	0.000	t	2.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
219	OREO ORIGINAL 220G x5	Alcool	0.00	4.50	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
220	PATE DE SARDINELLE	Autre	0.00	3.90	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
221	PCD PATE ARACHIDE 500G	Autre	0.00	3.60	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
222	PETIT ECOLIER POCK 10	Autre	0.00	4.50	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
223	PILCHARDS 400G	Autre	0.00	2.90	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
224	PILCHARDS 425G	Autre	0.00	2.90	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
225	POLIAKOV 70CL	Autre	0.00	15.90	20.00	0.000	t	3.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
226	PORTO CRUZ 75CL	Alcool	0.00	16.95	20.00	0.000	t	2.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
227	PORTO CRUZ TAWNY 70CL	Alcool	0.00	26.90	20.00	0.000	t	2.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
228	PRAISE PALM CREAM	Autre	0.00	2.90	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
229	PRINCE CHOCO 300G	Autre	0.00	2.90	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
230	PROVENC TOMAT 425G	Autre	0.00	3.50	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
231	PUY VALLON 70CL	Autre	0.00	11.90	20.00	0.000	t	5.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
232	Pain Au Lait Et Pépites De Chocolat	Autre	0.00	2.80	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
233	Pepsi	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
234	Pepsi 1 L	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
235	Pepsi 1,5L	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
236	Pepsi Max	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
237	Pepsi Zéro Sleek 33 Cl	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
238	Pepsi Zéro Sucres 1 L	Autre	0.00	1.00	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
239	Pepsi Zéro Sucres 50 Cl	Autre	0.00	1.00	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
240	Pepsi Zéro Sucres Saveur Cerise 1,5 L	Autre	0.00	1.00	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
241	Perle d'asie - riz long parfume QS 20kg	Autre	0.00	47.90	5.50	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
242	Perle d'asie - riz parfume casse 1F 5KG	Autre	0.00	10.90	5.50	0.000	t	3.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
243	Petit marseillais - fleur d'oranger bio 250ml	Autre	0.00	3.90	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
244	Picon bière à l’orange 1L	Alcool	0.00	37.50	20.00	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
245	Punched Goût Tropical Goyave 50 Cl	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
246	RED LABEL 35CL	Autre	0.00	14.90	20.00	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
247	RIBEAUPIERRE 2023	Boissons	0.00	7.90	5.50	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
248	RIZ LOTUS 2OKG	Autre	0.00	44.99	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
249	RIZ LOTUS LONG 5KG	Autre	0.00	15.90	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
250	RIZ ROND 1KG	Autre	0.00	2.95	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
251	RIZ SUNMALI 10K	Autre	0.00	24.90	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
252	ROC DE CAZADE 75CL	Autre	0.00	12.99	20.00	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
253	ROCHAMBEAU PAIN AU CHOCO 360G	Boissons	0.00	2.99	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
254	ROCHAMBEAU PAIN AU LAIT 350G	Boissons	0.00	2.80	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
255	ROMA OIL - SUNFLOWER	Autre	0.00	2.50	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
256	Rochambeau flageolets verts	Boissons	0.00	1.30	5.50	0.000	t	2.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
257	Rockstar Energy Drink Goût Fraise Citron Vert	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
258	SAMIA HARICO BLANCS	Autre	0.00	1.50	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
259	SAMIA POIS CHICHES	Autre	0.00	1.99	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
260	SAUCE TOMATE CUISINE.	Autre	0.00	3.50	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
261	SEL DE TABLE 750G	Autre	0.00	1.20	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
262	SMIRNOFF 70CL	Autre	0.00	17.90	20.00	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
263	SMIRNOFF MIXED 70CL	Autre	0.00	4.50	20.00	0.000	t	2.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
264	SOBIESKI 70CL	Autre	0.00	17.90	20.00	0.000	t	4.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
265	SOBIESKI VODKA 35CL	Alcool	0.00	11.90	20.00	0.000	t	3.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
266	ST MICHEL SABLE RETZ 120G	Autre	0.00	2.20	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
267	SUCRE EN POUDRE 1KG	Autre	0.00	2.52	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
268	SUCRE MORCEAUX 1KG	Boissons	0.00	3.50	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
269	Sauce Tomate Basilic	Autre	0.00	2.50	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
270	Sel De Table	Autre	0.00	1.50	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
271	Smarties 38g	Autre	0.00	109.99	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
272	Sprite Goût Original — canette 33 cl	Alcool	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
273	Sprite Goût Original — canette 33 cl (FR ref.)	Alcool	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
274	Sprite Goût Original — canette 33 cl (UK)	Alcool	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
275	Sprite Goût Original — canette 33 cl (ancien)	Alcool	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
276	Sprite Ice — canette 33 cl	Autre	0.00	0.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
277	TERSOL RIZ PARFUME 1KG	Autre	0.00	3.50	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
278	THON ENTIER 400G	Autre	0.00	4.99	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
279	THON SAUPIQUET 800G	Autre	0.00	7.90	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
280	TILDA RIZ LONG BASMAT 1KG	Autre	0.00	4.50	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
281	TROFAI 400G	Autre	0.00	3.50	20.00	0.000	t	11.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
282	Thon Au Naturel	Autre	0.00	3.90	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
283	TopoChico TANGY LEMOM LIME	Autre	0.00	1.00	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
284	VIEUX PAPES 75CL	Autre	0.00	14.50	20.00	0.000	t	7.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
285	VILLAGEOISE 0.75L	Autre	0.00	4.90	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
286	VINAIGRE DE RAISIN	Alcool	0.00	2.50	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
287	VOLKA PYLA 70CL	Autre	0.00	38.90	20.00	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
288	VOLKA STOLI 70CL	Autre	0.00	16.90	20.00	0.000	t	1.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
289	Vinaigre Balsamique à La Truffe	Alcool	0.00	19.50	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
290	WALIMA	Autre	0.00	1.90	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
291	WALIMA RIZ LONG ETUVE 1K	Autre	0.00	2.80	5.50	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
292	WILLIAM LAW 700ML	Autre	0.00	21.90	20.00	0.000	t	2.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
293	WILLIAM PEEL 35CL	Autre	0.00	11.90	20.00	0.000	t	2.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
294	WILLIAM PEEL 70CL	Autre	0.00	19.50	20.00	0.000	t	2.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
295	WYBOROWA VODKA 70CL	Alcool	0.00	25.90	20.00	0.000	t	3.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
296	ZWAN 340G	Autre	0.00	3.90	20.00	0.000	t	0.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
3	$5410316947022	Autre	0.00	1.60	5.50	0.000	t	387.000	2025-10-30 11:54:29.494117	2025-10-30 11:54:29.494117
\.


--
-- Data for Name: produits_barcodes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.produits_barcodes (id, produit_id, code, symbologie, pays_iso2, is_principal, created_at) FROM stdin;
1	1	3258561220734.0	\N	\N	f	2025-10-30 11:54:29.494117
2	2	5000267013602.0	\N	\N	f	2025-10-30 11:54:29.494117
3	3	nan	\N	\N	f	2025-10-30 11:54:29.494117
4	4	8717438769837.0	\N	\N	f	2025-10-30 11:54:29.494117
5	5	3168930159834.0	\N	\N	f	2025-10-30 11:54:29.494117
6	6	3502110001900.0	\N	\N	f	2025-10-30 11:54:29.494117
7	7	3168930161769.0	\N	\N	f	2025-10-30 11:54:29.494117
8	8	3168930161738.0	\N	\N	f	2025-10-30 11:54:29.494117
9	9	3502110009036.0	\N	\N	f	2025-10-30 11:54:29.494117
10	10	3168930159773.0	\N	\N	f	2025-10-30 11:54:29.494117
11	11	3168930159865.0	\N	\N	f	2025-10-30 11:54:29.494117
12	12	3168930159803.0	\N	\N	f	2025-10-30 11:54:29.494117
13	13	7312040017683.0	\N	\N	f	2025-10-30 11:54:29.494117
14	14	3760137910531.0	\N	\N	f	2025-10-30 11:54:29.494117
15	15	3760137911040.0	\N	\N	f	2025-10-30 11:54:29.494117
16	16	8904064616264.0	\N	\N	f	2025-10-30 11:54:29.494117
17	17	6111260550212.0	\N	\N	f	2025-10-30 11:54:29.494117
18	18	3276650116102.0	\N	\N	f	2025-10-30 11:54:29.494117
19	19	3439495112184.0	\N	\N	f	2025-10-30 11:54:29.494117
20	20	3439495113488.0	\N	\N	f	2025-10-30 11:54:29.494117
21	21	5010677014205.0	\N	\N	f	2025-10-30 11:54:29.494117
22	22	3011932009952.0	\N	\N	f	2025-10-30 11:54:29.494117
23	23	5000299610688.0	\N	\N	f	2025-10-30 11:54:29.494117
24	24	3258561020112.0	\N	\N	f	2025-10-30 11:54:29.494117
25	25	3439497015285.0	\N	\N	f	2025-10-30 11:54:29.494117
26	26	3185110012673.0	\N	\N	f	2025-10-30 11:54:29.494117
27	27	3258561510408.0	\N	\N	f	2025-10-30 11:54:29.494117
28	28	3258561040257.0	\N	\N	f	2025-10-30 11:54:29.494117
29	29	3258561040356.0	\N	\N	f	2025-10-30 11:54:29.494117
30	30	3258561020716.0	\N	\N	f	2025-10-30 11:54:29.494117
31	31	3258561500744.0	\N	\N	f	2025-10-30 11:54:29.494117
32	32	3258561510255.0	\N	\N	f	2025-10-30 11:54:29.494117
33	33	3258561500768.0	\N	\N	f	2025-10-30 11:54:29.494117
34	34	3258561240763.0	\N	\N	f	2025-10-30 11:54:29.494117
35	35	3258561240237.0	\N	\N	f	2025-10-30 11:54:29.494117
36	36	3258561212333.0	\N	\N	f	2025-10-30 11:54:29.494117
37	37	3258561220246.0	\N	\N	f	2025-10-30 11:54:29.494117
38	38	3258561019147.0	\N	\N	f	2025-10-30 11:54:29.494117
39	39	3258561020938.0	\N	\N	f	2025-10-30 11:54:29.494117
40	40	3258561211220.0	\N	\N	f	2025-10-30 11:54:29.494117
41	41	3258561211466.0	\N	\N	f	2025-10-30 11:54:29.494117
42	42	3258561240664.0	\N	\N	f	2025-10-30 11:54:29.494117
43	43	3258561180212.0	\N	\N	f	2025-10-30 11:54:29.494117
44	44	3258561240336.0	\N	\N	f	2025-10-30 11:54:29.494117
45	45	3258561240244.0	\N	\N	f	2025-10-30 11:54:29.494117
46	46	3258561240282.0	\N	\N	f	2025-10-30 11:54:29.494117
47	47	3258561211756.0	\N	\N	f	2025-10-30 11:54:29.494117
48	48	3258561211459.0	\N	\N	f	2025-10-30 11:54:29.494117
49	49	3258561220239.0	\N	\N	f	2025-10-30 11:54:29.494117
50	50	3258561142104.0	\N	\N	f	2025-10-30 11:54:29.494117
51	51	3258561240268.0	\N	\N	f	2025-10-30 11:54:29.494117
52	52	3258561211404.0	\N	\N	f	2025-10-30 11:54:29.494117
53	53	3258561500263.0	\N	\N	f	2025-10-30 11:54:29.494117
54	54	3258561301013.0	\N	\N	f	2025-10-30 11:54:29.494117
55	55	3258561221168.0	\N	\N	f	2025-10-30 11:54:29.494117
56	56	3258561650371.0	\N	\N	f	2025-10-30 11:54:29.494117
57	57	32585616510354.0	\N	\N	f	2025-10-30 11:54:29.494117
58	58	3258561510378.0	\N	\N	f	2025-10-30 11:54:29.494117
59	59	3258561670201.0	\N	\N	f	2025-10-30 11:54:29.494117
60	60	3258561510569.0	\N	\N	f	2025-10-30 11:54:29.494117
61	61	3258561510545.0	\N	\N	f	2025-10-30 11:54:29.494117
62	62	3258561510286.0	\N	\N	f	2025-10-30 11:54:29.494117
63	63	3258561500416.0	\N	\N	f	2025-10-30 11:54:29.494117
64	64	3258561670195.0	\N	\N	f	2025-10-30 11:54:29.494117
65	65	3258561670652.0	\N	\N	f	2025-10-30 11:54:29.494117
66	66	3258561670690.0	\N	\N	f	2025-10-30 11:54:29.494117
67	67	3258561640013.0	\N	\N	f	2025-10-30 11:54:29.494117
68	68	5901867816498.0	\N	\N	f	2025-10-30 11:54:29.494117
69	69	5410673005076.0	\N	\N	f	2025-10-30 11:54:29.494117
70	70	5000267024202.0	\N	\N	f	2025-10-30 11:54:29.494117
71	71	3258561211497.0	\N	\N	f	2025-10-30 11:54:29.494117
72	72	3258561211251.0	\N	\N	f	2025-10-30 11:54:29.494117
73	73	3083680025881.0	\N	\N	f	2025-10-30 11:54:29.494117
74	74	3020254463755.0	\N	\N	f	2025-10-30 11:54:29.494117
75	75	3020254463465.0	\N	\N	f	2025-10-30 11:54:29.494117
76	76	3020254463779.0	\N	\N	f	2025-10-30 11:54:29.494117
77	77	3760045044199.0	\N	\N	f	2025-10-30 11:54:29.494117
78	78	3179071000978.0	\N	\N	f	2025-10-30 11:54:29.494117
79	79	7616100005079.0	\N	\N	f	2025-10-30 11:54:29.494117
80	80	4017773301131.0	\N	\N	f	2025-10-30 11:54:29.494117
81	81	3258561210889.0	\N	\N	f	2025-10-30 11:54:29.494117
82	82	3290350555553.0	\N	\N	f	2025-10-30 11:54:29.494117
83	83	3259354503003.0	\N	\N	f	2025-10-30 11:54:29.494117
84	84	3211209139232.0	\N	\N	f	2025-10-30 11:54:29.494117
85	85	3451201439903.0	\N	\N	f	2025-10-30 11:54:29.494117
86	86	3182520295146.0	\N	\N	f	2025-10-30 11:54:29.494117
87	87	80432402931.0	\N	\N	f	2025-10-30 11:54:29.494117
88	88	3760151401206.0	\N	\N	f	2025-10-30 11:54:29.494117
89	89	5010103938235.0	\N	\N	f	2025-10-30 11:54:29.494117
90	90	5010103916738.0	\N	\N	f	2025-10-30 11:54:29.494117
91	91	5010103999991.0	\N	\N	f	2025-10-30 11:54:29.494117
92	92	3163937635008.0	\N	\N	f	2025-10-30 11:54:29.494117
93	93	3047360102088.0	\N	\N	f	2025-10-30 11:54:29.494117
94	94	3439495503272.0	\N	\N	f	2025-10-30 11:54:29.494117
95	95	5449000009500.0	\N	\N	f	2025-10-30 11:54:29.494117
96	96	5449000214812.0	\N	\N	f	2025-10-30 11:54:29.494117
97	97	5449000214799.0	\N	\N	f	2025-10-30 11:54:29.494117
98	98	5449000214911.0	\N	\N	f	2025-10-30 11:54:29.494117
99	99	5449000214843.0	\N	\N	f	2025-10-30 11:54:29.494117
100	100	5449000195364.0	\N	\N	f	2025-10-30 11:54:29.494117
101	101	5942321002590.0	\N	\N	f	2025-10-30 11:54:29.494117
102	102	5449000239761.0	\N	\N	f	2025-10-30 11:54:29.494117
103	103	54490000009960.0	\N	\N	f	2025-10-30 11:54:29.494117
104	104	50112128.0	\N	\N	f	2025-10-30 11:54:29.494117
105	105	54492509.0	\N	\N	f	2025-10-30 11:54:29.494117
106	106	5449000308023.0	\N	\N	f	2025-10-30 11:54:29.494117
107	107	54490147.0	\N	\N	f	2025-10-30 11:54:29.494117
108	108	5449000267412.0	\N	\N	f	2025-10-30 11:54:29.494117
109	109	5000112639995.0	\N	\N	f	2025-10-30 11:54:29.494117
110	110	5449000267467.0	\N	\N	f	2025-10-30 11:54:29.494117
111	111	5449000054227.0	\N	\N	f	2025-10-30 11:54:29.494117
112	112	3174780000363.0	\N	\N	f	2025-10-30 11:54:29.494117
113	113	5449000000996.0	\N	\N	f	2025-10-30 11:54:29.494117
114	113	5000112638769.0	\N	\N	f	2025-10-30 11:54:29.494117
115	114	5740700988349.0	\N	\N	f	2025-10-30 11:54:29.494117
116	115	5000112545326.0	\N	\N	f	2025-10-30 11:54:29.494117
117	116	5449000016560.0	\N	\N	f	2025-10-30 11:54:29.494117
118	117	5449000089229.0	\N	\N	f	2025-10-30 11:54:29.494117
119	118	5449000056672.0	\N	\N	f	2025-10-30 11:54:29.494117
120	119	5000112611786.0	\N	\N	f	2025-10-30 11:54:29.494117
121	120	5449000050205.0	\N	\N	f	2025-10-30 11:54:29.494117
122	121	5449000275165.0	\N	\N	f	2025-10-30 11:54:29.494117
123	122	5449000252920.0	\N	\N	f	2025-10-30 11:54:29.494117
124	123	5449000131805.0	\N	\N	f	2025-10-30 11:54:29.494117
125	123	5000112592054.0	\N	\N	f	2025-10-30 11:54:29.494117
126	123	5000112519945.0	\N	\N	f	2025-10-30 11:54:29.494117
127	124	5740700982965.0	\N	\N	f	2025-10-30 11:54:29.494117
128	125	5000112554359.0	\N	\N	f	2025-10-30 11:54:29.494117
129	126	8000040000802.0	\N	\N	f	2025-10-30 11:54:29.494117
130	127	3038359010507.0	\N	\N	f	2025-10-30 11:54:29.494117
131	128	3165432534008.0	\N	\N	f	2025-10-30 11:54:29.494117
132	129	3760239453462.0	\N	\N	f	2025-10-30 11:54:29.494117
133	130	3014230002601.0	\N	\N	f	2025-10-30 11:54:29.494117
134	131	8410414000466.0	\N	\N	f	2025-10-30 11:54:29.494117
135	132	5010436503018.0	\N	\N	f	2025-10-30 11:54:29.494117
136	133	5010436500000.0	\N	\N	f	2025-10-30 11:54:29.494117
137	134	5010436500017.0	\N	\N	f	2025-10-30 11:54:29.494117
138	135	3258565100063.0	\N	\N	f	2025-10-30 11:54:29.494117
139	136	3483050000041.0	\N	\N	f	2025-10-30 11:54:29.494117
140	137	5000112650402.0	\N	\N	f	2025-10-30 11:54:29.494117
141	138	5449000006004.0	\N	\N	f	2025-10-30 11:54:29.494117
142	139	5740700994203.0	\N	\N	f	2025-10-30 11:54:29.494117
143	140	5449000286932.0	\N	\N	f	2025-10-30 11:54:29.494117
144	141	5449000214829.0	\N	\N	f	2025-10-30 11:54:29.494117
145	142	5740700996153.0	\N	\N	f	2025-10-30 11:54:29.494117
146	142	5740700991691.0	\N	\N	f	2025-10-30 11:54:29.494117
147	143	5000112514124.0	\N	\N	f	2025-10-30 11:54:29.494117
148	143	5000112579390.0	\N	\N	f	2025-10-30 11:54:29.494117
149	143	5000112673036.0	\N	\N	f	2025-10-30 11:54:29.494117
150	144	5740700987984.0	\N	\N	f	2025-10-30 11:54:29.494117
151	145	5000112517163.0	\N	\N	f	2025-10-30 11:54:29.494117
152	145	5000112649710.0	\N	\N	f	2025-10-30 11:54:29.494117
153	146	5000112641998.0	\N	\N	f	2025-10-30 11:54:29.494117
154	147	5000112515848.0	\N	\N	f	2025-10-30 11:54:29.494117
155	148	5449000011527.0	\N	\N	f	2025-10-30 11:54:29.494117
156	149	5449000287038.0	\N	\N	f	2025-10-30 11:54:29.494117
157	150	5000112637946.0	\N	\N	f	2025-10-30 11:54:29.494117
158	150	5000112628937.0	\N	\N	f	2025-10-30 11:54:29.494117
159	150	5000112638783.0	\N	\N	f	2025-10-30 11:54:29.494117
160	150	5000112552119.0	\N	\N	f	2025-10-30 11:54:29.494117
161	151	5449000027153.0	\N	\N	f	2025-10-30 11:54:29.494117
162	152	5449000291677.0	\N	\N	f	2025-10-30 11:54:29.494117
163	153	8710605018684.0	\N	\N	f	2025-10-30 11:54:29.494117
164	154	647458031073.0	\N	\N	f	2025-10-30 11:54:29.494117
165	155	3147690060703.0	\N	\N	f	2025-10-30 11:54:29.494117
166	156	7622210601988.0	\N	\N	f	2025-10-30 11:54:29.494117
167	157	5010327250007.0	\N	\N	f	2025-10-30 11:54:29.494117
168	158	3664284000018.0	\N	\N	f	2025-10-30 11:54:29.494117
169	159	6036000065910.0	\N	\N	f	2025-10-30 11:54:29.494117
170	160	5908234813067.0	\N	\N	f	2025-10-30 11:54:29.494117
171	161	3263281733679.0	\N	\N	f	2025-10-30 11:54:29.494117
172	162	3245995960015.0	\N	\N	f	2025-10-30 11:54:29.494117
173	163	9555008101316.0	\N	\N	f	2025-10-30 11:54:29.494117
174	164	3168930159988.0	\N	\N	f	2025-10-30 11:54:29.494117
175	165	3168930170310.0	\N	\N	f	2025-10-30 11:54:29.494117
176	166	5099873046173.0	\N	\N	f	2025-10-30 11:54:29.494117
177	167	3099873045864.0	\N	\N	f	2025-10-30 11:54:29.494117
178	168	5099873017623.0	\N	\N	f	2025-10-30 11:54:29.494117
179	169	5099873008270.0	\N	\N	f	2025-10-30 11:54:29.494117
180	170	5099873001370.0	\N	\N	f	2025-10-30 11:54:29.494117
181	171	5060095330029.0	\N	\N	f	2025-10-30 11:54:29.494117
182	172	5010103800853.0	\N	\N	f	2025-10-30 11:54:29.494117
183	173	5010103800259.0	\N	\N	f	2025-10-30 11:54:29.494117
184	174	4060800100252.0	\N	\N	f	2025-10-30 11:54:29.494117
185	175	3439495508802.0	\N	\N	f	2025-10-30 11:54:29.494117
186	176	3439495521108.0	\N	\N	f	2025-10-30 11:54:29.494117
187	177	3263286301323.0	\N	\N	f	2025-10-30 11:54:29.494117
188	178	3211209272243.0	\N	\N	f	2025-10-30 11:54:29.494117
189	179	3587222521508.0	\N	\N	f	2025-10-30 11:54:29.494117
190	180	3259356626007.0	\N	\N	f	2025-10-30 11:54:29.494117
191	181	8011988003060.0	\N	\N	f	2025-10-30 11:54:29.494117
192	182	3147699102008.0	\N	\N	f	2025-10-30 11:54:29.494117
193	183	3147690051206.0	\N	\N	f	2025-10-30 11:54:29.494117
194	184	3434435161017.0	\N	\N	f	2025-10-30 11:54:29.494117
195	185	3258561020297.0	\N	\N	f	2025-10-30 11:54:29.494117
196	186	3276650013210.0	\N	\N	f	2025-10-30 11:54:29.494117
197	187	3142952144016.0	\N	\N	f	2025-10-30 11:54:29.494117
198	188	3259356633005.0	\N	\N	f	2025-10-30 11:54:29.494117
199	189	3168930172994.0	\N	\N	f	2025-10-30 11:54:29.494117
200	190	3168930162711.0	\N	\N	f	2025-10-30 11:54:29.494117
201	191	3502110009142.0	\N	\N	f	2025-10-30 11:54:29.494117
202	192	3168930170600.0	\N	\N	f	2025-10-30 11:54:29.494117
203	193	3168930159896.0	\N	\N	f	2025-10-30 11:54:29.494117
204	194	3168930170549.0	\N	\N	f	2025-10-30 11:54:29.494117
205	195	3168930171058.0	\N	\N	f	2025-10-30 11:54:29.494117
206	196	3228881072276.0	\N	\N	f	2025-10-30 11:54:29.494117
207	197	3168930166016.0	\N	\N	f	2025-10-30 11:54:29.494117
208	198	3502110006844.0	\N	\N	f	2025-10-30 11:54:29.494117
209	199	3502110009234.0	\N	\N	f	2025-10-30 11:54:29.494117
210	200	3168930159926.0	\N	\N	f	2025-10-30 11:54:29.494117
211	201	3258561210162.0	\N	\N	f	2025-10-30 11:54:29.494117
212	202	7613033486050.0	\N	\N	f	2025-10-30 11:54:29.494117
213	203	3112940130109.0	\N	\N	f	2025-10-30 11:54:29.494117
214	204	3700019511081.0	\N	\N	f	2025-10-30 11:54:29.494117
215	205	3259353235004.0	\N	\N	f	2025-10-30 11:54:29.494117
216	206	7622300503079.0	\N	\N	f	2025-10-30 11:54:29.494117
217	207	7622300344757.0	\N	\N	f	2025-10-30 11:54:29.494117
218	208	3563490010029.0	\N	\N	f	2025-10-30 11:54:29.494117
219	209	3502110003485.0	\N	\N	f	2025-10-30 11:54:29.494117
220	210	3502110002884.0	\N	\N	f	2025-10-30 11:54:29.494117
221	210	8710398521682.0	\N	\N	f	2025-10-30 11:54:29.494117
222	211	3502110002679.0	\N	\N	f	2025-10-30 11:54:29.494117
223	212	3168930161707.0	\N	\N	f	2025-10-30 11:54:29.494117
224	213	3502110002686.0	\N	\N	f	2025-10-30 11:54:29.494117
225	214	3502110004192.0	\N	\N	f	2025-10-30 11:54:29.494117
226	215	5060751219156.0	\N	\N	f	2025-10-30 11:54:29.494117
227	216	3438931.0	\N	\N	f	2025-10-30 11:54:29.494117
228	217	3438931000597.0	\N	\N	f	2025-10-30 11:54:29.494117
229	218	3020254425715.0	\N	\N	f	2025-10-30 11:54:29.494117
230	219	7623300744663.0	\N	\N	f	2025-10-30 11:54:29.494117
231	220	6044000064000.0	\N	\N	f	2025-10-30 11:54:29.494117
232	221	8710411045058.0	\N	\N	f	2025-10-30 11:54:29.494117
233	222	7622210422026.0	\N	\N	f	2025-10-30 11:54:29.494117
234	223	5110817000256.0	\N	\N	f	2025-10-30 11:54:29.494117
235	224	5110817000232.0	\N	\N	f	2025-10-30 11:54:29.494117
236	225	3147690061007.0	\N	\N	f	2025-10-30 11:54:29.494117
237	226	3147699118368.0	\N	\N	f	2025-10-30 11:54:29.494117
238	227	3147699118351.0	\N	\N	f	2025-10-30 11:54:29.494117
239	228	6034000115215.0	\N	\N	f	2025-10-30 11:54:29.494117
240	229	7622210449283.0	\N	\N	f	2025-10-30 11:54:29.494117
241	230	3258561140629.0	\N	\N	f	2025-10-30 11:54:29.494117
242	231	3439495520729.0	\N	\N	f	2025-10-30 11:54:29.494117
243	232	3439496604008.0	\N	\N	f	2025-10-30 11:54:29.494117
244	233	4060800102683.0	\N	\N	f	2025-10-30 11:54:29.494117
245	234	4060800009449.0	\N	\N	f	2025-10-30 11:54:29.494117
246	235	3502110008329.0	\N	\N	f	2025-10-30 11:54:29.494117
247	236	3502110009357.0	\N	\N	f	2025-10-30 11:54:29.494117
248	237	3168930159742.0	\N	\N	f	2025-10-30 11:54:29.494117
249	238	3502110010049.0	\N	\N	f	2025-10-30 11:54:29.494117
250	239	3502110000651.0	\N	\N	f	2025-10-30 11:54:29.494117
251	240	3502110006295.0	\N	\N	f	2025-10-30 11:54:29.494117
252	241	3276650013753.0	\N	\N	f	2025-10-30 11:54:29.494117
253	242	3276650018826.0	\N	\N	f	2025-10-30 11:54:29.494117
254	243	3574661700823.0	\N	\N	f	2025-10-30 11:54:29.494117
255	244	5010103931502.0	\N	\N	f	2025-10-30 11:54:29.494117
256	245	8710398521712.0	\N	\N	f	2025-10-30 11:54:29.494117
257	246	5000267014807.0	\N	\N	f	2025-10-30 11:54:29.494117
258	247	3439495506723.0	\N	\N	f	2025-10-30 11:54:29.494117
259	248	3276650013289.0	\N	\N	f	2025-10-30 11:54:29.494117
260	249	3276650013265.0	\N	\N	f	2025-10-30 11:54:29.494117
261	250	3276650010011.0	\N	\N	f	2025-10-30 11:54:29.494117
262	251	8847102310031.0	\N	\N	f	2025-10-30 11:54:29.494117
263	252	354295000015.0	\N	\N	f	2025-10-30 11:54:29.494117
264	253	3439496604015.0	\N	\N	f	2025-10-30 11:54:29.494117
265	254	3439496603995.0	\N	\N	f	2025-10-30 11:54:29.494117
266	255	3020254964290.0	\N	\N	f	2025-10-30 11:54:29.494117
267	256	3439497014370.0	\N	\N	f	2025-10-30 11:54:29.494117
268	257	8710398523952.0	\N	\N	f	2025-10-30 11:54:29.494117
269	258	3276650101177.0	\N	\N	f	2025-10-30 11:54:29.494117
270	259	3276650101153.0	\N	\N	f	2025-10-30 11:54:29.494117
271	260	3038359011412.0	\N	\N	f	2025-10-30 11:54:29.494117
272	261	3165720448833.0	\N	\N	f	2025-10-30 11:54:29.494117
273	262	5410316671118.0	\N	\N	f	2025-10-30 11:54:29.494117
274	263	5410316947053.0	\N	\N	f	2025-10-30 11:54:29.494117
275	264	5902738887876.0	\N	\N	f	2025-10-30 11:54:29.494117
276	265	5902738883106.0	\N	\N	f	2025-10-30 11:54:29.494117
277	266	3023470010017.0	\N	\N	f	2025-10-30 11:54:29.494117
278	267	3220035560004.0	\N	\N	f	2025-10-30 11:54:29.494117
279	268	3220034072003.0	\N	\N	f	2025-10-30 11:54:29.494117
280	269	3258561140599.0	\N	\N	f	2025-10-30 11:54:29.494117
281	270	3439495112900.0	\N	\N	f	2025-10-30 11:54:29.494117
282	271	40345192.0	\N	\N	f	2025-10-30 11:54:29.494117
283	272	5449000286291.0	\N	\N	f	2025-10-30 11:54:29.494117
284	272	5449000227966.0	\N	\N	f	2025-10-30 11:54:29.494117
285	272	5449000214775.0	\N	\N	f	2025-10-30 11:54:29.494117
286	272	5449000286314.0	\N	\N	f	2025-10-30 11:54:29.494117
287	273	3665676000869.0	\N	\N	f	2025-10-30 11:54:29.494117
288	274	5000112557695.0	\N	\N	f	2025-10-30 11:54:29.494117
289	275	5449000006288.0	\N	\N	f	2025-10-30 11:54:29.494117
290	276	5449000099976.0	\N	\N	f	2025-10-30 11:54:29.494117
291	277	3513083900008.0	\N	\N	f	2025-10-30 11:54:29.494117
292	278	3760105892142.0	\N	\N	f	2025-10-30 11:54:29.494117
293	279	3165950218695.0	\N	\N	f	2025-10-30 11:54:29.494117
294	280	5011157630274.0	\N	\N	f	2025-10-30 11:54:29.494117
295	281	3700019511180.0	\N	\N	f	2025-10-30 11:54:29.494117
296	282	3760020063191.0	\N	\N	f	2025-10-30 11:54:29.494117
297	283	5449000294746.0	\N	\N	f	2025-10-30 11:54:29.494117
298	284	3175529632302.0	\N	\N	f	2025-10-30 11:54:29.494117
299	285	8719689681104.0	\N	\N	f	2025-10-30 11:54:29.494117
300	286	8411831000572.0	\N	\N	f	2025-10-30 11:54:29.494117
301	287	3760224900018.0	\N	\N	f	2025-10-30 11:54:29.494117
302	288	4750021000065.0	\N	\N	f	2025-10-30 11:54:29.494117
303	289	3527904420224.0	\N	\N	f	2025-10-30 11:54:29.494117
304	290	3760197940783.0	\N	\N	f	2025-10-30 11:54:29.494117
305	291	3760197947799.0	\N	\N	f	2025-10-30 11:54:29.494117
306	292	5010752000307.0	\N	\N	f	2025-10-30 11:54:29.494117
307	293	3107872006523.0	\N	\N	f	2025-10-30 11:54:29.494117
308	294	3107872000507.0	\N	\N	f	2025-10-30 11:54:29.494117
309	295	5900685006197.0	\N	\N	f	2025-10-30 11:54:29.494117
310	296	8710581916028.0	\N	\N	f	2025-10-30 11:54:29.494117
311	297	5425021580495	\N	\N	f	2025-10-30 12:05:49.521322
312	298	3220036870003	\N	\N	f	2025-10-30 12:05:49.521322
313	299	3439495204087	\N	\N	f	2025-10-30 12:05:49.521322
314	300	3528960006599	\N	\N	f	2025-10-30 12:05:49.521322
315	301	3660407045591	\N	\N	f	2025-10-30 12:05:49.521322
316	302	4337182242567	\N	\N	f	2025-10-30 12:05:49.521322
317	303	3760151050565	\N	\N	f	2025-10-30 12:05:49.521322
318	304	4006133246434	\N	\N	f	2025-10-30 12:05:49.521322
319	305	3573972112905	\N	\N	f	2025-10-30 12:05:49.521322
320	306	4337182210054	\N	\N	f	2025-10-30 12:05:49.521322
321	307	4337182222545	\N	\N	f	2025-10-30 12:05:49.521322
322	308	4337182222484	\N	\N	f	2025-10-30 12:05:49.521322
323	309	8410087366258	\N	\N	f	2025-10-30 12:06:22.270134
324	310	3760387550730	\N	\N	f	2025-10-30 12:06:22.270134
325	311	3760298920004	\N	\N	f	2025-10-30 12:06:22.270134
326	312	3439496513850	\N	\N	f	2025-10-30 12:06:22.270134
327	313	4337125000087	\N	\N	f	2025-10-30 12:06:22.270134
328	314	3660131205179	\N	\N	f	2025-10-30 12:06:22.270134
329	315	5010327325125	\N	\N	f	2025-10-30 12:06:46.790014
330	316	3211200184743	\N	\N	f	2025-10-30 12:06:46.790014
331	317	3439495507928	\N	\N	f	2025-10-30 12:06:46.790014
332	318	3259356633067	\N	\N	f	2025-10-30 12:06:46.790014
333	319	4017773301148	\N	\N	f	2025-10-30 12:06:46.790014
334	320	5410228203582	\N	\N	f	2025-10-30 12:06:46.790014
335	321	3155930400530	\N	\N	f	2025-10-30 12:06:46.790014
336	322	3119783016690	\N	\N	f	2025-10-30 12:06:46.790014
337	323	03124488193904	\N	\N	f	2025-10-30 12:06:46.790014
338	324	3124488194741	\N	\N	f	2025-10-30 12:06:46.790014
339	325	5449000214942	\N	\N	f	2025-10-30 12:06:46.790014
340	326	3168930159841	\N	\N	f	2025-10-30 12:06:46.790014
341	327	3295921504202	\N	\N	f	2025-10-30 12:06:46.790014
342	328	3295921144200	\N	\N	f	2025-10-30 12:06:46.790014
343	329	04008400264004	\N	\N	f	2025-10-30 12:06:46.790014
344	330	5000159555722	\N	\N	f	2025-10-30 12:06:46.790014
345	331	5000159461801	\N	\N	f	2025-10-30 12:06:46.790014
346	332	5000159561679	\N	\N	f	2025-10-30 12:06:46.790014
347	333	3185110012673	\N	\N	f	2025-10-30 12:06:46.790014
348	334	3281130011181	\N	\N	f	2025-10-30 12:06:46.790014
349	335	3439497015285	\N	\N	f	2025-10-30 12:06:46.790014
350	336	8445290872036	\N	\N	f	2025-10-30 12:06:46.790014
351	337	3329770048690	\N	\N	f	2025-10-30 12:06:46.790014
352	338	3329770048676	\N	\N	f	2025-10-30 12:06:46.790014
353	339	3329770063273	\N	\N	f	2025-10-30 12:06:46.790014
354	340	3329770063280	\N	\N	f	2025-10-30 12:06:46.790014
355	341	3033491974212	\N	\N	f	2025-10-30 12:06:46.790014
356	342	3033491974175	\N	\N	f	2025-10-30 12:06:46.790014
357	343	3439496002323	\N	\N	f	2025-10-30 12:06:46.790014
358	344	3587222521508	\N	\N	f	2025-10-30 12:06:46.790014
359	345	3439496604015	\N	\N	f	2025-10-30 12:06:46.790014
360	346	3439496603995	\N	\N	f	2025-10-30 12:06:46.790014
361	347	3439496604008	\N	\N	f	2025-10-30 12:06:46.790014
362	348	4337182142485	\N	\N	f	2025-10-30 12:06:46.790014
363	349	3760261148305	\N	\N	f	2025-10-30 12:06:46.790014
364	350	3701479402162	\N	\N	f	2025-10-30 12:06:46.790014
365	351	3439496821689	\N	\N	f	2025-10-30 12:06:46.790014
366	352	3119783018823	\N	\N	f	2025-10-30 12:07:11.398554
367	353	3103220035559	\N	\N	f	2025-10-30 12:07:11.398554
368	354	5410228223580	\N	\N	f	2025-10-30 12:07:45.054577
369	355	3439496010304	\N	\N	f	2025-10-30 12:07:45.054577
370	356	3439496607221	\N	\N	f	2025-10-30 12:07:45.054577
371	357	3439496000657	\N	\N	f	2025-10-30 12:07:45.054577
372	358	4337182249283	\N	\N	f	2025-10-30 12:07:45.054577
373	359	4337182249290	\N	\N	f	2025-10-30 12:07:45.054577
374	360	4337182219897	\N	\N	f	2025-10-30 12:07:45.054577
375	361	3439496810997	\N	\N	f	2025-10-30 12:07:45.054577
376	310	3770015716223	\N	\N	f	2025-10-30 12:08:00.448408
377	362	4337182219835	\N	\N	f	2025-10-30 12:08:00.448408
378	363	3378927661459	\N	\N	f	2025-10-30 12:08:00.448408
379	364	4337182219798	\N	\N	f	2025-10-30 12:08:00.448408
380	365	3147697510607	\N	\N	f	2025-10-30 12:08:25.252336
381	366	3257150100228	\N	\N	f	2025-10-30 12:08:25.252336
382	367	3175529657725	\N	\N	f	2025-10-30 12:08:25.252336
383	368	3259354102060	\N	\N	f	2025-10-30 12:08:25.252336
384	369	03179077103147	\N	\N	f	2025-10-30 12:08:25.252336
385	370	03179077103154	\N	\N	f	2025-10-30 12:08:25.252336
386	371	3439495600360	\N	\N	f	2025-10-30 12:08:25.252336
387	372	3080210003425	\N	\N	f	2025-10-30 12:08:25.252336
388	373	3439495405064	\N	\N	f	2025-10-30 12:08:25.252336
389	374	3439495403794	\N	\N	f	2025-10-30 12:08:25.252336
390	375	3439495405040	\N	\N	f	2025-10-30 12:08:25.252336
391	376	3439495406320	\N	\N	f	2025-10-30 12:08:25.252336
392	377	3439495406368	\N	\N	f	2025-10-30 12:08:25.252336
393	378	5000112557091	\N	\N	f	2025-10-30 12:08:25.252336
394	379	8002270116551	\N	\N	f	2025-10-30 12:08:25.252336
395	380	3179730004804	\N	\N	f	2025-10-30 12:08:25.252336
396	381	3439495111699	\N	\N	f	2025-10-30 12:08:25.252336
397	382	4337182248705	\N	\N	f	2025-10-30 12:08:25.252336
398	383	3281130011129	\N	\N	f	2025-10-30 12:08:25.252336
399	384	3439496303628	\N	\N	f	2025-10-30 12:08:25.252336
400	385	3439496807805	\N	\N	f	2025-10-30 12:08:25.252336
401	386	3439495501568	\N	\N	f	2025-10-30 12:08:39.842775
402	387	3179077103161	\N	\N	f	2025-10-30 12:08:39.842775
403	388	3438935000135	\N	\N	f	2025-10-30 12:08:39.842775
404	389	03439495113495	\N	\N	f	2025-10-30 12:08:39.842775
405	390	03439495112917	\N	\N	f	2025-10-30 12:08:39.842775
406	391	3439495102796	\N	\N	f	2025-10-30 12:08:39.842775
407	392	3168930121961	\N	\N	f	2025-10-30 12:08:39.842775
408	393	3168930104285	\N	\N	f	2025-10-30 12:08:39.842775
409	394	4337182138341	\N	\N	f	2025-10-30 12:08:39.842775
410	395	3430430008678	\N	\N	f	2025-10-30 12:09:02.576379
411	396	3430430008685	\N	\N	f	2025-10-30 12:09:02.576379
412	397	3439495508345	\N	\N	f	2025-10-30 12:09:02.576379
413	398	3211200284900	\N	\N	f	2025-10-30 12:09:02.576379
414	399	3049614222252	\N	\N	f	2025-10-30 12:09:02.576379
415	400	05000267024325	\N	\N	f	2025-10-30 12:09:38.699924
416	401	4337182250159	\N	\N	f	2025-10-30 12:09:38.699924
417	402	5000299225004	\N	\N	f	2025-10-30 12:10:16.733895
418	403	5900685006197	\N	\N	f	2025-10-30 12:10:16.733895
419	404	5410316671118	\N	\N	f	2025-10-30 12:10:16.733895
420	405	8410414000466	\N	\N	f	2025-10-30 12:10:16.733895
421	406	7312040017683	\N	\N	f	2025-10-30 12:10:16.733895
422	407	5901867816498	\N	\N	f	2025-10-30 12:10:16.733895
423	408	3147699102701	\N	\N	f	2025-10-30 12:10:16.733895
424	409	3147690093602	\N	\N	f	2025-10-30 12:10:16.733895
425	410	3147690094708	\N	\N	f	2025-10-30 12:10:16.733895
426	411	3451201439910	\N	\N	f	2025-10-30 12:10:16.733895
427	412	3439495520736	\N	\N	f	2025-10-30 12:10:16.733895
428	413	3447456333011	\N	\N	f	2025-10-30 12:10:16.733895
429	414	13439495521105	\N	\N	f	2025-10-30 12:10:16.733895
430	415	3292350635989	\N	\N	f	2025-10-30 12:10:16.733895
431	416	3439495403824	\N	\N	f	2025-10-30 12:10:16.733895
432	417	3439495405514	\N	\N	f	2025-10-30 12:10:16.733895
433	418	3075711382018	\N	\N	f	2025-10-30 12:10:16.733895
434	419	3439495108811	\N	\N	f	2025-10-30 12:10:16.733895
435	420	08000500121467	\N	\N	f	2025-10-30 12:10:16.733895
436	421	4009900396417	\N	\N	f	2025-10-30 12:10:16.733895
437	422	8723400943907	\N	\N	f	2025-10-30 12:10:16.733895
438	423	4009900017824	\N	\N	f	2025-10-30 12:10:16.733895
439	424	8723400943303	\N	\N	f	2025-10-30 12:10:16.733895
440	425	8723400943204	\N	\N	f	2025-10-30 12:10:16.733895
441	426	8723400943235	\N	\N	f	2025-10-30 12:10:16.733895
442	427	6931722310297	\N	\N	f	2025-10-30 12:10:16.733895
443	428	3587220003525	\N	\N	f	2025-10-30 12:10:16.733895
444	429	3439496623788	\N	\N	f	2025-10-30 12:10:16.733895
445	430	3700133920943	\N	\N	f	2025-10-30 12:10:16.733895
446	431	3378740763996	\N	\N	f	2025-10-30 12:10:16.733895
447	432	3378740764924	\N	\N	f	2025-10-30 12:10:16.733895
448	433	3378740856704	\N	\N	f	2025-10-30 12:10:16.733895
449	434	3378740001623	\N	\N	f	2025-10-30 12:10:16.733895
450	435	2352965012665	\N	\N	f	2025-10-30 12:10:16.733895
451	436	8710438110524	\N	\N	f	2025-10-30 12:10:16.733895
452	437	3760261140354	\N	\N	f	2025-10-30 12:10:16.733895
453	438	3439496807065	\N	\N	f	2025-10-30 12:10:16.733895
454	439	3099873045864	\N	\N	f	2025-10-30 12:10:43.935296
455	440	5000267024325	\N	\N	f	2025-10-30 12:10:43.935296
456	441	3175529665812	\N	\N	f	2025-10-30 12:10:43.935296
457	442	3282946037716	\N	\N	f	2025-10-30 12:10:43.935296
458	443	3124488194734	\N	\N	f	2025-10-30 12:10:43.935296
459	444	3124488151492	\N	\N	f	2025-10-30 12:10:43.935296
460	445	7613035833289	\N	\N	f	2025-10-30 12:10:43.935296
461	446	03174660116702	\N	\N	f	2025-10-30 12:10:43.935296
462	447	5053990164165	\N	\N	f	2025-10-30 12:10:43.935296
463	448	5053990156016	\N	\N	f	2025-10-30 12:10:43.935296
464	449	5053990162710	\N	\N	f	2025-10-30 12:10:43.935296
465	450	5053990155361	\N	\N	f	2025-10-30 12:10:43.935296
466	451	8000500121467	\N	\N	f	2025-10-30 12:10:43.935296
467	452	4337182096870	\N	\N	f	2025-10-30 12:10:43.935296
468	453	5099873089057	\N	\N	f	2025-10-30 12:10:59.277817
469	454	20080432402935	\N	\N	f	2025-10-30 12:10:59.277817
470	455	05000299225332	\N	\N	f	2025-10-30 12:10:59.277817
471	456	05010327248059	\N	\N	f	2025-10-30 12:10:59.277817
472	457	5099873219386	\N	\N	f	2025-10-30 12:10:59.277817
473	458	7312040017355	\N	\N	f	2025-10-30 12:10:59.277817
474	459	5011013100613	\N	\N	f	2025-10-30 12:10:59.277817
475	460	7630040408295	\N	\N	f	2025-10-30 12:10:59.277817
476	461	7630040408639	\N	\N	f	2025-10-30 12:10:59.277817
477	462	7630040408493	\N	\N	f	2025-10-30 12:10:59.277817
478	463	0080432402931	\N	\N	f	2025-10-30 12:11:25.7753
479	464	3760221470026	\N	\N	f	2025-10-30 12:11:25.7753
480	465	5011013100156	\N	\N	f	2025-10-30 12:11:25.7753
481	466	3119780268276	\N	\N	f	2025-10-30 12:11:25.7753
482	467	3490949909033	\N	\N	f	2025-10-30 12:11:25.7753
483	468	0000000031010	\N	\N	f	2025-10-30 12:11:25.7753
484	469	5010494564273	\N	\N	f	2025-10-30 12:11:39.640331
485	470	5000267102573	\N	\N	f	2025-10-30 12:11:39.640331
486	471	5010196111010	\N	\N	f	2025-10-30 12:11:39.640331
487	472	4901903064105	\N	\N	f	2025-10-30 12:11:39.640331
488	473	5010314302863	\N	\N	f	2025-10-30 12:11:39.640331
489	474	5010327325323	\N	\N	f	2025-10-30 12:11:39.640331
490	475	05010327105000	\N	\N	f	2025-10-30 12:11:39.640331
491	476	8001250121240	\N	\N	f	2025-10-30 12:11:39.640331
492	477	3439496827254	\N	\N	f	2025-10-30 12:11:39.640331
493	365	03147691302390	\N	\N	f	2025-10-30 12:11:53.816872
494	478	03119783018847	\N	\N	f	2025-10-30 12:11:53.816872
495	479	9002490205997	\N	\N	f	2025-10-30 12:11:53.816872
496	480	5060335632333	\N	\N	f	2025-10-30 12:11:53.816872
497	481	5449000017673	\N	\N	f	2025-10-30 12:11:53.816872
498	482	8711000705162	\N	\N	f	2025-10-30 12:11:53.816872
\.


--
-- Name: mouvements_stock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mouvements_stock_id_seq', 457, true);


--
-- Name: produits_barcodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produits_barcodes_id_seq', 498, true);


--
-- Name: produits_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produits_id_seq', 482, true);


--
-- Name: mouvements_stock mouvements_stock_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mouvements_stock
    ADD CONSTRAINT mouvements_stock_pkey PRIMARY KEY (id);


--
-- Name: produits_barcodes produits_barcodes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produits_barcodes
    ADD CONSTRAINT produits_barcodes_pkey PRIMARY KEY (id);


--
-- Name: produits produits_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produits
    ADD CONSTRAINT produits_pkey PRIMARY KEY (id);


--
-- Name: idx_barcode_produit; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_barcode_produit ON public.produits_barcodes USING btree (produit_id);


--
-- Name: idx_mouvements_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_mouvements_date ON public.mouvements_stock USING btree (date_mvt);


--
-- Name: idx_mouvements_produit; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_mouvements_produit ON public.mouvements_stock USING btree (produit_id);


--
-- Name: uix_barcodes_code_ci; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uix_barcodes_code_ci ON public.produits_barcodes USING btree (lower(code));


--
-- Name: uix_produits_nom_ci; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uix_produits_nom_ci ON public.produits USING btree (lower(nom));


--
-- Name: mouvements_stock trg_update_stock_actuel; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_update_stock_actuel AFTER INSERT ON public.mouvements_stock FOR EACH ROW EXECUTE FUNCTION public.update_stock_actuel();


--
-- Name: mouvements_stock mouvements_stock_produit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mouvements_stock
    ADD CONSTRAINT mouvements_stock_produit_id_fkey FOREIGN KEY (produit_id) REFERENCES public.produits(id) ON DELETE CASCADE;


--
-- Name: produits_barcodes produits_barcodes_produit_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produits_barcodes
    ADD CONSTRAINT produits_barcodes_produit_id_fkey FOREIGN KEY (produit_id) REFERENCES public.produits(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict DZCW6HzODzkNglkXRprWnA2N4URLjpg4ol9X5wKZg1eYTS9jCyWgY0gsDUJ5XfI

